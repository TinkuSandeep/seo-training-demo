@echo off
call "%~dp0Run-OcpHealthCheck.cmd"
echo.
echo Exit code: %ERRORLEVEL%
pause
