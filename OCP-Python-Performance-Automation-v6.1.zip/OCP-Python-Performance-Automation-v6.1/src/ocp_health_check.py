from __future__ import annotations
import argparse, csv, html, json, os, re, shutil, smtplib, sqlite3, subprocess, sys, threading, time, traceback
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from email.message import EmailMessage
from pathlib import Path
from typing import Any, Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
from uuid import uuid4

VERSION = "6.1.0"

@dataclass
class Result:
    timestamp: str
    run_id: str
    datacenter: str
    cluster: str
    application: str
    project: str
    resource_type: str
    resource_name: str
    severity: str
    status: str
    details: str
    evidence_file: str = ""

@dataclass
class PerformanceResult:
    timestamp: str
    run_id: str
    datacenter: str
    cluster: str
    application: str
    project: str
    workload: str
    pod: str
    target_pods: int
    cpu_usage_cores: float
    cpu_request_cores: float
    cpu_limit_cores: float
    cpu_request_utilization_percent: float | None
    cpu_limit_utilization_percent: float | None
    memory_usage_mib: float
    memory_request_mib: float
    memory_limit_mib: float
    memory_request_utilization_percent: float | None
    memory_limit_utilization_percent: float | None
    recommended_cpu_request_cores: float
    recommended_cpu_limit_cores: float
    recommended_memory_request_mib: float
    recommended_memory_limit_mib: float
    severity: str
    finding: str

@dataclass
class CapacityResult:
    datacenter: str
    cluster: str
    application: str
    project: str
    workload: str
    current_pods: int
    target_pods: int
    observed_cpu_cores: float
    observed_memory_mib: float
    recommended_cpu_request_per_pod: float
    recommended_cpu_limit_per_pod: float
    recommended_memory_request_mib_per_pod: float
    recommended_memory_limit_mib_per_pod: float
    target_utilization_percent: float
    limit_multiplier: float
    basis: str

@dataclass
class AutoscalingReadinessResult:
    timestamp: str
    run_id: str
    datacenter: str
    cluster: str
    application: str
    project: str
    workload: str
    hpa: str
    current_replicas: int
    desired_replicas: int
    min_replicas: int
    max_replicas: int
    scaling_headroom: int
    metric_vs_target: str
    target_exists: bool
    resource_requests_ready: bool
    pdb: str
    pdb_allowed_disruptions: int | None
    unschedulable_pods: int
    nodes: int
    zones: int
    recent_scaling_events: int
    sustained_samples: int
    sustained_high_utilization: bool
    severity: str
    status: str
    recommendation: str

class Logger:
    def __init__(self, path: Path, run_id: str):
        self.path, self.run_id = path, run_id
    def write(self, level: str, message: str, **data: Any):
        rec = {"timestamp": datetime.now(timezone.utc).isoformat(), "run_id": self.run_id,
               "level": level, "message": message, **data}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        print(f"[{level}] {message}")

class Checker:
    def __init__(self, cfg: dict[str, Any], cfg_path: Path, out_root: Path):
        self.cfg, self.cfg_path, self.out_root = cfg, cfg_path, out_root
        self.run_id = f"{datetime.now():%Y%m%d-%H%M%S}-{uuid4().hex[:8]}"
        self.run_dir = out_root / self.run_id
        self.evidence_dir = self.run_dir / "evidence"
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self.evidence_dir.mkdir(parents=True, exist_ok=True)
        self.logger = Logger(self.run_dir/"execution.jsonl", self.run_id)
        self.results: list[Result] = []
        self.performance_results: list[PerformanceResult] = []
        self.performance_lock = threading.Lock()
        self.autoscaling_results: list[AutoscalingReadinessResult] = []
        self.autoscaling_lock = threading.Lock()
        self.scope = threading.local()
        self.results_lock = threading.Lock()
        self.evidence_lock = threading.Lock()
        self.evidence_count = 0
        cluster_cfg = cfg.get("cluster", {})
        self.oc = self.resolve_oc(str(cluster_cfg.get("oc_executable", "oc")))
        self.timeout = int(cluster_cfg.get("command_timeout_seconds", 60))

    def resolve_oc(self, configured: str) -> str:
        p = Path(configured)
        if not p.is_absolute() and ("\\" in configured or "/" in configured):
            p = (self.cfg_path.parent / p).resolve()
        if p.exists():
            return str(p)
        return shutil.which(configured) or shutil.which("oc.exe") or shutil.which("oc") or configured

    def oc_run(self, args: list[str], check: bool=True) -> subprocess.CompletedProcess[str]:
        scope_cfg = getattr(self.scope, "config", {}) or {}
        scope_args: list[str] = []
        kubeconfig = str(scope_cfg.get("kubeconfig", "")).strip()
        context = str(scope_cfg.get("context", "")).strip()
        server = str(scope_cfg.get("server", "")).strip()
        token_env = str(scope_cfg.get("token_environment_variable", "")).strip()
        token = os.environ.get(token_env, "").strip() if token_env else ""
        if kubeconfig:
            scope_args.append(f"--kubeconfig={kubeconfig}")
        if context:
            scope_args.append(f"--context={context}")
        if server:
            scope_args.append(f"--server={server}")
        if token:
            scope_args.append(f"--token={token}")
        if scope_cfg.get("insecure_skip_tls_verify", False):
            scope_args.append("--insecure-skip-tls-verify=true")
        cmd = [self.oc, *scope_args, *args]
        safe = ["--token=<redacted>" if x.startswith("--token=") else x for x in cmd]
        self.logger.write("DEBUG", "Running oc command.", command=safe)
        try:
            p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                               errors="replace", timeout=self.timeout, check=False)
        except FileNotFoundError as e:
            raise RuntimeError(f"oc executable not found: {self.oc}") from e
        except subprocess.TimeoutExpired as e:
            raise RuntimeError(f"Command timed out after {self.timeout}s: {' '.join(safe)}") from e
        if check and p.returncode != 0:
            raise RuntimeError((p.stderr or p.stdout or "oc command failed").strip())
        return p

    def oc_json(self, args: list[str]) -> dict[str, Any]:
        p = self.oc_run([*args, "-o", "json"])
        return json.loads(p.stdout) if p.stdout.strip() else {}

    def retry(self, description: str, fn: Callable[[], Any]) -> Any:
        exe = self.cfg["execution"]
        count = int(exe.get("max_retries", 3))
        delay0 = float(exe.get("initial_retry_delay_seconds", 2))
        last = None
        for n in range(1, count+1):
            try:
                return fn()
            except Exception as e:
                last = e
                if n == count: break
                delay = min(30, delay0 * 2**(n-1))
                self.logger.write("WARN", f"{description} failed; retrying.",
                                  attempt=n, delay_seconds=delay, error=str(e))
                time.sleep(delay)
        raise RuntimeError(f"{description} failed after {count} attempts: {last}")

    def add(self, app: str, project: str, typ: str, name: str, severity: str,
            status: str, details: str, evidence: str=""):
        scope_cfg = getattr(self.scope, "config", {}) or {}
        result = Result(datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            self.run_id, str(scope_cfg.get("name", self.cfg.get("cluster", {}).get("datacenter", "default"))),
            str(scope_cfg.get("cluster", self.cfg.get("cluster", {}).get("name", "unknown"))), app, project, typ,
            name, severity, status, details, evidence)
        with self.results_lock:
            self.results.append(result)

    @staticmethod
    def age_minutes(ts: str) -> float:
        dt = datetime.fromisoformat(ts.replace("Z","+00:00"))
        return (datetime.now(timezone.utc)-dt.astimezone(timezone.utc)).total_seconds()/60

    @staticmethod
    def quantity_to_float(value: str) -> float:
        if value is None: return 0.0
        s = str(value).strip()
        units = {
            "n": 1e-9, "u": 1e-6, "m": 1e-3,
            "Ki": 1024, "Mi": 1024**2, "Gi": 1024**3, "Ti": 1024**4,
            "K": 1000, "M": 1000**2, "G": 1000**3, "T": 1000**4
        }
        for unit in sorted(units, key=len, reverse=True):
            if s.endswith(unit):
                return float(s[:-len(unit)]) * units[unit]
        try: return float(s)
        except ValueError: return 0.0

    @classmethod
    def cpu_cores(cls, value: str | None) -> float:
        return cls.quantity_to_float(value or "0")

    @classmethod
    def memory_mib(cls, value: str | None) -> float:
        return cls.quantity_to_float(value or "0") / (1024 ** 2)

    def enabled(self, key: str) -> bool:
        return bool(self.cfg.get("checks", {}).get(key, True))

    def validate(self):
        who = self.oc_run(["whoami"], check=False)
        if who.returncode != 0 or not who.stdout.strip():
            scope_cfg = getattr(self.scope, "config", {}) or {}
            if any(scope_cfg.get(key) for key in ("context", "kubeconfig", "server")):
                raise RuntimeError(
                    f"No valid OpenShift session for datacenter {scope_cfg.get('name', 'unknown')}. "
                    "Verify context/kubeconfig or the configured token environment variable."
                )
            self.logger.write("WARN", "OpenShift session is invalid; attempting configured login recovery.")
            self.recover_login()
            who = self.oc_run(["whoami"], check=False)
        if who.returncode != 0 or not who.stdout.strip():
            raise RuntimeError("No valid oc login session after recovery attempt.")
        self.logger.write("INFO", "OpenShift session validated.", user=who.stdout.strip())

    def recover_login(self):
        login = self.cfg.get("authentication", {})
        if not login.get("enabled", False):
            raise RuntimeError("Automatic login recovery is disabled. Run oc login or enable authentication settings.")
        server = str(login.get("server", "")).strip()
        token_env = str(login.get("token_environment_variable", "OCP_TOKEN")).strip()
        token = os.environ.get(token_env, "").strip()
        if not server or not token:
            raise RuntimeError(f"Automatic login requires authentication.server and environment variable {token_env}.")
        args = ["login", server, f"--token={token}"]
        if login.get("insecure_skip_tls_verify", False):
            args.append("--insecure-skip-tls-verify=true")
        p = self.oc_run(args, check=False)
        if p.returncode != 0:
            raise RuntimeError((p.stderr or p.stdout or "oc login failed").strip())
        self.logger.write("INFO", "OpenShift login recovery succeeded.")

    def check_project(self, app: str, project: str, scope_cfg: dict[str, Any], target_pods: int | None = None):
        self.scope.config = scope_cfg
        self.scope.target_pods = target_pods
        self.logger.write("INFO", "Checking project.", application=app, project=project,
                          datacenter=scope_cfg.get("name"), cluster=scope_cfg.get("cluster"))
        try:
            self.retry(f"project {project}", lambda: self.oc_json(["get","project",project]))
        except Exception as e:
            self.add(app, project, "Project", project, "Critical", "Unavailable", str(e)); return

        if self.enabled("pods"): self.check_pods(app, project)
        if self.enabled("controllers"): self.check_controllers(app, project)
        if self.enabled("persistent_volume_claims"): self.check_pvcs(app, project)
        if self.enabled("services_and_endpoints"): self.check_services(app, project)
        if self.enabled("routes"): self.check_routes(app, project)
        if self.enabled("horizontal_pod_autoscalers"): self.check_hpa(app, project)
        if self.enabled("replica_sets"): self.check_replicasets(app, project)
        if self.enabled("resource_quotas"): self.check_quotas(app, project)
        if self.enabled("limit_ranges"): self.check_limitranges(app, project)
        if self.enabled("node_placement"): self.check_node_placement(app, project)
        if self.enabled("pod_metrics"): self.check_metrics(app, project)
        if self.enabled("autoscaling_readiness"): self.check_autoscaling_readiness(app, project)
        if self.enabled("warning_events"): self.check_events(app, project)

    def check_pods(self, app: str, project: str):
        try: items = self.retry("pods", lambda: self.oc_json(["get","pods","-n",project])).get("items",[])
        except Exception as e:
            self.add(app,project,"PodQuery",project,"Critical","QueryFailed",str(e)); return
        if not items:
            self.add(app,project,"Pod","(none)","Warning","NoPods","No pods found."); return
        t = self.cfg["thresholds"]
        bad_reasons = {"CrashLoopBackOff","ImagePullBackOff","ErrImagePull","CreateContainerConfigError",
                       "CreateContainerError","RunContainerError","OOMKilled","Error"}
        for pod in items:
            md, st = pod.get("metadata",{}), pod.get("status",{})
            name, phase = str(md.get("name","unknown")), str(st.get("phase","Unknown"))
            sev, problems = "Healthy", []
            for c in st.get("conditions",[]) or []:
                if c.get("type")=="Ready" and c.get("status")!="True" and phase!="Succeeded":
                    sev="Critical"; problems.append(f"Ready={c.get('status')}")
            for cs in list(st.get("initContainerStatuses",[]) or []) + list(st.get("containerStatuses",[]) or []):
                cname = str(cs.get("name","unknown")); restarts=int(cs.get("restartCount",0) or 0)
                state=cs.get("state",{}) or {}; reason=""
                for k in ("waiting","terminated"):
                    if isinstance(state.get(k),dict) and state[k].get("reason"): reason=str(state[k]["reason"])
                if not cs.get("ready",False) and phase!="Succeeded":
                    sev="Critical"; problems.append(f"{cname} not ready")
                if reason in bad_reasons:
                    sev="Critical"; problems.append(f"{cname} reason={reason}")
                if restarts >= int(t["restart_critical"]):
                    sev="Critical"; problems.append(f"{cname} restarts={restarts}")
                elif restarts >= int(t["restart_warning"]) and sev!="Critical":
                    sev="Warning"; problems.append(f"{cname} restarts={restarts}")
            if phase=="Pending" and md.get("creationTimestamp"):
                age=self.age_minutes(md["creationTimestamp"])
                if age >= int(t["pending_critical_minutes"]): sev="Critical"; problems.append(f"Pending {age:.1f}m")
                elif age >= int(t["pending_warning_minutes"]) and sev!="Critical": sev="Warning"; problems.append(f"Pending {age:.1f}m")
            elif phase not in {"Running","Succeeded"}:
                sev="Critical"; problems.append(f"phase={phase}")
            evidence=self.collect_logs(project,name) if sev in {"Warning","Critical"} else ""
            self.add(app,project,"Pod",name,sev,phase,"; ".join(dict.fromkeys(problems)) or "Ready",evidence)

    def collect_logs(self, project: str, pod: str) -> str:
        e=self.cfg["execution"]
        with self.evidence_lock:
            if not e.get("collect_unhealthy_pod_logs",True) or self.evidence_count>=int(e.get("maximum_evidence_files_per_run",20)):
                return ""
            self.evidence_count += 1
        safe=lambda s: re.sub(r"[^A-Za-z0-9_.-]","_",s)
        path=self.evidence_dir/f"{safe(project)}--{safe(pod)}.log"
        p=self.oc_run(["logs",pod,"-n",project,"--all-containers=true",f"--tail={int(e.get('log_tail_lines',200))}","--timestamps=true"],check=False)
        path.write_text((p.stdout or "")+("\n"+p.stderr if p.stderr else ""),encoding="utf-8",errors="replace")
        return str(path)

    def check_controllers(self, app: str, project: str):
        for resource,label in [("deployments","Deployment"),("deploymentconfigs","DeploymentConfig"),
                               ("statefulsets","StatefulSet"),("daemonsets","DaemonSet")]:
            try: items=self.oc_json(["get",resource,"-n",project]).get("items",[])
            except Exception as e:
                self.logger.write("WARN","Controller query failed.",project=project,resource=resource,error=str(e)); continue
            for x in items:
                md,spec,st=x.get("metadata",{}),x.get("spec",{}),x.get("status",{})
                if resource=="daemonsets":
                    desired=int(st.get("desiredNumberScheduled",0) or 0); ready=int(st.get("numberReady",0) or 0); avail=int(st.get("numberAvailable",ready) or 0)
                else:
                    desired=int(spec.get("replicas",0) or 0); ready=int(st.get("readyReplicas",0) or 0); avail=int(st.get("availableReplicas",ready) or 0)
                sev="Healthy" if ready>=desired and avail>=desired else "Critical"
                self.add(app,project,label,str(md.get("name","unknown")),sev,"Available" if sev=="Healthy" else "Unavailable",
                         f"Desired={desired}; Ready={ready}; Available={avail}")

    def check_pvcs(self, app: str, project: str):
        try: items=self.oc_json(["get","pvc","-n",project]).get("items",[])
        except Exception as e:
            self.logger.write("WARN","PVC query failed.",project=project,error=str(e)); return
        t=self.cfg["thresholds"]
        for x in items:
            md,st=x.get("metadata",{}),x.get("status",{})
            name,phase=str(md.get("name","unknown")),str(st.get("phase","Unknown"))
            sev="Healthy"; details=f"Phase={phase}"
            if phase=="Pending":
                age=self.age_minutes(md["creationTimestamp"]) if md.get("creationTimestamp") else 0
                sev="Critical" if age>=int(t["pvc_pending_critical_minutes"]) else "Warning"
                details+=f"; AgeMinutes={age:.1f}"
            elif phase not in {"Bound"}: sev="Critical"
            cap=(st.get("capacity",{}) or {}).get("storage")
            if cap: details+=f"; Capacity={cap}"
            self.add(app,project,"PVC",name,sev,phase,details)

    def check_services(self, app: str, project: str):
        try:
            svcs=self.oc_json(["get","services","-n",project]).get("items",[])
            eps=self.oc_json(["get","endpoints","-n",project]).get("items",[])
        except Exception as e:
            self.logger.write("WARN","Service/endpoints query failed.",project=project,error=str(e)); return
        epmap={x.get("metadata",{}).get("name"):x for x in eps}
        for svc in svcs:
            md,spec=svc.get("metadata",{}),svc.get("spec",{})
            name=str(md.get("name","unknown")); typ=str(spec.get("type","ClusterIP"))
            selectors=spec.get("selector") or {}
            subsets=(epmap.get(name,{}) or {}).get("subsets",[]) or []
            addresses=sum(len(s.get("addresses",[]) or []) for s in subsets)
            if not selectors or typ=="ExternalName":
                sev="Healthy"; status="Configured"
            elif addresses>0:
                sev="Healthy"; status="EndpointsReady"
            else:
                sev="Critical"; status="NoReadyEndpoints"
            self.add(app,project,"Service",name,sev,status,
                     f"Type={typ}; ReadyEndpointAddresses={addresses}; Ports={len(spec.get('ports',[]) or [])}")

    def check_routes(self, app: str, project: str):
        try: items=self.oc_json(["get","routes.route.openshift.io","-n",project]).get("items",[])
        except Exception as e:
            self.logger.write("WARN","Route query failed.",project=project,error=str(e)); return
        configured=str(self.cfg["thresholds"].get("route_without_host_severity","Warning"))
        for x in items:
            md,spec,st=x.get("metadata",{}),x.get("spec",{}),x.get("status",{})
            name,host=str(md.get("name","unknown")),str(spec.get("host",""))
            admitted=False
            for ingress in st.get("ingress",[]) or []:
                for cond in ingress.get("conditions",[]) or []:
                    if cond.get("type")=="Admitted" and cond.get("status")=="True": admitted=True
            if not host: sev,status=configured,"NoHost"
            elif admitted: sev,status="Healthy","Admitted"
            else: sev,status="Warning","NotAdmitted"
            self.add(app,project,"Route",name,sev,status,f"Host={host or '(empty)'}; TLS={'yes' if spec.get('tls') else 'no'}")

    def check_hpa(self, app: str, project: str):
        try: items=self.oc_json(["get","hpa","-n",project]).get("items",[])
        except Exception as e:
            self.logger.write("WARN","HPA query failed.",project=project,error=str(e)); return
        warn=int(self.cfg["thresholds"].get("hpa_utilization_warning_percent",90))
        for x in items:
            md,spec,st=x.get("metadata",{}),x.get("spec",{}),x.get("status",{})
            name=str(md.get("name","unknown")); current=int(st.get("currentReplicas",0) or 0); desired=int(st.get("desiredReplicas",0) or 0)
            maxr=int(spec.get("maxReplicas",0) or 0); sev="Healthy"; issues=[]
            conds=st.get("conditions",[]) or []
            for c in conds:
                if c.get("type") in {"AbleToScale","ScalingActive"} and c.get("status")=="False":
                    sev="Warning"; issues.append(f"{c.get('type')}={c.get('reason')}")
            if maxr and current>=maxr and desired>=maxr:
                sev="Warning"; issues.append("At maximum replicas")
            self.add(app,project,"HPA",name,sev,"Active" if sev=="Healthy" else "Attention",
                     f"Current={current}; Desired={desired}; Min={spec.get('minReplicas',1)}; Max={maxr}" + (f"; {'; '.join(issues)}" if issues else ""))

    def check_replicasets(self, app: str, project: str):
        try: items=self.oc_json(["get","replicasets","-n",project]).get("items",[])
        except Exception as e:
            self.logger.write("WARN","ReplicaSet query failed.",project=project,error=str(e)); return
        for x in items:
            md,spec,st=x.get("metadata",{}),x.get("spec",{}),x.get("status",{})
            desired=int(spec.get("replicas",0) or 0); ready=int(st.get("readyReplicas",0) or 0)
            if desired==0: sev,status="Healthy","ScaledDown"
            elif ready<desired: sev,status="Warning","NotReady"
            else: sev,status="Healthy","Ready"
            self.add(app,project,"ReplicaSet",str(md.get("name","unknown")),sev,status,f"Desired={desired}; Ready={ready}")

    def check_quotas(self, app: str, project: str):
        try: items=self.oc_json(["get","resourcequota","-n",project]).get("items",[])
        except Exception as e:
            self.logger.write("WARN","Quota query failed.",project=project,error=str(e)); return
        tw,tc=self.cfg["thresholds"].get("quota_warning_percent",80),self.cfg["thresholds"].get("quota_critical_percent",95)
        for x in items:
            name=str(x.get("metadata",{}).get("name","unknown")); hard=x.get("status",{}).get("hard",{}) or {}; used=x.get("status",{}).get("used",{}) or {}
            worst=0.0; parts=[]
            for key,limit in hard.items():
                lv=self.quantity_to_float(str(limit)); uv=self.quantity_to_float(str(used.get(key,"0")))
                pct=(uv/lv*100) if lv>0 else 0; worst=max(worst,pct)
                parts.append(f"{key}={used.get(key,'0')}/{limit} ({pct:.1f}%)")
            sev="Critical" if worst>=tc else ("Warning" if worst>=tw else "Healthy")
            self.add(app,project,"ResourceQuota",name,sev,f"{worst:.1f}%","; ".join(parts) or "No status values")

    def check_limitranges(self, app: str, project: str):
        try: items=self.oc_json(["get","limitrange","-n",project]).get("items",[])
        except Exception as e:
            self.logger.write("WARN","LimitRange query failed.",project=project,error=str(e)); return
        if not items:
            self.add(app,project,"LimitRange","(none)","Warning","NotConfigured","No LimitRange found.")
        for x in items:
            name=str(x.get("metadata",{}).get("name","unknown")); limits=x.get("spec",{}).get("limits",[]) or []
            self.add(app,project,"LimitRange",name,"Healthy","Configured",f"Rules={len(limits)}")

    def check_node_placement(self, app: str, project: str):
        try: items=self.oc_json(["get","pods","-n",project]).get("items",[])
        except Exception as e:
            self.logger.write("WARN","Node placement query failed.",project=project,error=str(e)); return
        counts={}
        unscheduled=0
        for x in items:
            node=x.get("spec",{}).get("nodeName")
            if node: counts[node]=counts.get(node,0)+1
            elif x.get("status",{}).get("phase") not in {"Succeeded","Failed"}: unscheduled+=1
        sev="Warning" if unscheduled else "Healthy"
        detail="; ".join(f"{n}={c} pods" for n,c in sorted(counts.items())) or "No scheduled pods"
        if unscheduled: detail+=f"; Unscheduled={unscheduled}"
        self.add(app,project,"NodePlacement","ProjectDistribution",sev,"Distributed",detail)

    def check_metrics(self, app: str, project: str):
        """Collect live metrics and compare them with configured requests/limits.

        The metrics API is a point-in-time source. Repeated scheduled executions provide
        the trend history; long-range p95/p99 sizing requires a Prometheus/Thanos source.
        """
        try:
            pods = self.oc_json(["get", "pods", "-n", project]).get("items", [])
            raw = self.oc_run([
                "get", "--raw",
                f"/apis/metrics.k8s.io/v1beta1/namespaces/{project}/pods",
            ])
            metrics_items = json.loads(raw.stdout or "{}").get("items", [])
        except Exception as exc:
            self.add(app, project, "PodPerformance", "MetricsAPI", "Unknown", "Unavailable", str(exc))
            return

        metrics_by_pod = {str(x.get("metadata", {}).get("name", "")): x for x in metrics_items}
        perf_cfg = self.cfg.get("performance", {})
        target_util = max(1.0, float(perf_cfg.get("target_utilization_percent", 80)))
        limit_multiplier = max(1.0, float(perf_cfg.get("limit_multiplier", 1.5)))
        warn = float(perf_cfg.get("request_warning_percent", 80))
        critical = float(perf_cfg.get("request_critical_percent", 95))
        limit_warn = float(perf_cfg.get("limit_warning_percent", 90))
        target_override = int(getattr(self.scope, "target_pods", 0) or 0)

        collected = 0
        for pod in pods:
            md, spec, status = pod.get("metadata", {}), pod.get("spec", {}), pod.get("status", {})
            pod_name = str(md.get("name", "unknown"))
            if status.get("phase") != "Running" or pod_name not in metrics_by_pod:
                continue

            usage_map = {
                str(c.get("name", "")): c.get("usage", {}) or {}
                for c in metrics_by_pod[pod_name].get("containers", []) or []
            }
            cpu_usage = memory_usage = cpu_request = memory_request = cpu_limit = memory_limit = 0.0
            missing_requests: list[str] = []
            missing_limits: list[str] = []
            for container in spec.get("containers", []) or []:
                name = str(container.get("name", "unknown"))
                resources = container.get("resources", {}) or {}
                requests = resources.get("requests", {}) or {}
                limits = resources.get("limits", {}) or {}
                usage = usage_map.get(name, {})
                cpu_usage += self.cpu_cores(usage.get("cpu"))
                memory_usage += self.memory_mib(usage.get("memory"))
                cpu_request += self.cpu_cores(requests.get("cpu"))
                memory_request += self.memory_mib(requests.get("memory"))
                cpu_limit += self.cpu_cores(limits.get("cpu"))
                memory_limit += self.memory_mib(limits.get("memory"))
                if not requests.get("cpu") or not requests.get("memory"):
                    missing_requests.append(name)
                if not limits.get("cpu") or not limits.get("memory"):
                    missing_limits.append(name)

            def percent(used: float, configured: float) -> float | None:
                return (used / configured * 100.0) if configured > 0 else None

            cpu_req_pct, mem_req_pct = percent(cpu_usage, cpu_request), percent(memory_usage, memory_request)
            cpu_lim_pct, mem_lim_pct = percent(cpu_usage, cpu_limit), percent(memory_usage, memory_limit)
            severity, findings = "Healthy", []

            request_peak = max(x for x in [cpu_req_pct, mem_req_pct] if x is not None) if any(
                x is not None for x in [cpu_req_pct, mem_req_pct]
            ) else None
            limit_peak = max(x for x in [cpu_lim_pct, mem_lim_pct] if x is not None) if any(
                x is not None for x in [cpu_lim_pct, mem_lim_pct]
            ) else None
            if request_peak is not None and request_peak >= critical:
                severity = "Critical"
                findings.append(f"request utilization reached {request_peak:.1f}%")
            elif request_peak is not None and request_peak >= warn:
                severity = "Warning"
                findings.append(f"request utilization reached {request_peak:.1f}%")
            if limit_peak is not None and limit_peak >= 100:
                severity = "Critical"
                findings.append(f"usage reached/exceeded {limit_peak:.1f}% of a configured limit")
            elif limit_peak is not None and limit_peak >= limit_warn and severity != "Critical":
                severity = "Warning"
                findings.append(f"limit utilization reached {limit_peak:.1f}%")
            if missing_requests and severity == "Healthy":
                severity = str(perf_cfg.get("missing_requests_severity", "Warning"))
                findings.append("CPU or memory request missing")
            if missing_limits and bool(perf_cfg.get("warn_on_missing_limits", True)) and severity == "Healthy":
                severity = "Warning"
                findings.append("CPU or memory limit missing")

            owner = next(iter(md.get("ownerReferences", []) or []), {})
            workload = f"{owner.get('kind', 'Pod')}/{owner.get('name', pod_name)}"
            recommended_cpu_request = cpu_usage / (target_util / 100.0) if cpu_usage else 0.0
            recommended_memory_request = memory_usage / (target_util / 100.0) if memory_usage else 0.0
            scope_cfg = getattr(self.scope, "config", {}) or {}
            target_pods = target_override or 0
            perf = PerformanceResult(
                timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                run_id=self.run_id,
                datacenter=str(scope_cfg.get("name", "default")),
                cluster=str(scope_cfg.get("cluster", self.cfg.get("cluster", {}).get("name", "unknown"))),
                application=app,
                project=project,
                workload=workload,
                pod=pod_name,
                target_pods=target_pods,
                cpu_usage_cores=round(cpu_usage, 6),
                cpu_request_cores=round(cpu_request, 6),
                cpu_limit_cores=round(cpu_limit, 6),
                cpu_request_utilization_percent=round(cpu_req_pct, 2) if cpu_req_pct is not None else None,
                cpu_limit_utilization_percent=round(cpu_lim_pct, 2) if cpu_lim_pct is not None else None,
                memory_usage_mib=round(memory_usage, 2),
                memory_request_mib=round(memory_request, 2),
                memory_limit_mib=round(memory_limit, 2),
                memory_request_utilization_percent=round(mem_req_pct, 2) if mem_req_pct is not None else None,
                memory_limit_utilization_percent=round(mem_lim_pct, 2) if mem_lim_pct is not None else None,
                recommended_cpu_request_cores=round(recommended_cpu_request, 3),
                recommended_cpu_limit_cores=round(recommended_cpu_request * limit_multiplier, 3),
                recommended_memory_request_mib=round(recommended_memory_request, 1),
                recommended_memory_limit_mib=round(recommended_memory_request * limit_multiplier, 1),
                severity=severity,
                finding="; ".join(findings) or "Within configured performance thresholds",
            )
            with self.performance_lock:
                self.performance_results.append(perf)
            collected += 1
            cpu_detail = (
                f"CPU={cpu_usage:.3f} cores ({cpu_req_pct:.1f}% of request)"
                if cpu_req_pct is not None else f"CPU={cpu_usage:.3f} cores (request missing)"
            )
            memory_detail = (
                f"Memory={memory_usage:.1f} MiB ({mem_req_pct:.1f}% of request)"
                if mem_req_pct is not None else f"Memory={memory_usage:.1f} MiB (request missing)"
            )
            self.add(
                app, project, "PodPerformance", pod_name, severity, "Measured",
                f"{cpu_detail}; {memory_detail}; {perf.finding}",
            )

        if not collected:
            self.add(app, project, "PodPerformance", "MetricsAPI", "Unknown", "NoData", "No running pod metrics returned.")

    @staticmethod
    def selector_matches(labels: dict[str, Any], selector: dict[str, Any] | None) -> bool:
        """Return True when Kubernetes labels satisfy a LabelSelector."""
        if not selector:
            return False
        for key, value in (selector.get("matchLabels", {}) or {}).items():
            if str(labels.get(key)) != str(value):
                return False
        for expression in selector.get("matchExpressions", []) or []:
            key = str(expression.get("key", ""))
            operator = str(expression.get("operator", ""))
            values = {str(value) for value in expression.get("values", []) or []}
            present = key in labels
            if operator == "In" and (not present or str(labels.get(key)) not in values):
                return False
            if operator == "NotIn" and present and str(labels.get(key)) in values:
                return False
            if operator == "Exists" and not present:
                return False
            if operator == "DoesNotExist" and present:
                return False
        return True

    @staticmethod
    def workload_selector(workload: dict[str, Any]) -> dict[str, Any]:
        spec = workload.get("spec", {}) or {}
        selector = spec.get("selector", {}) or {}
        if selector.get("matchLabels") or selector.get("matchExpressions"):
            return selector
        if selector:
            return {"matchLabels": selector}
        labels = ((spec.get("template", {}) or {}).get("metadata", {}) or {}).get("labels", {}) or {}
        return {"matchLabels": labels} if labels else {}

    @staticmethod
    def hpa_metric_summary(spec: dict[str, Any], status: dict[str, Any]) -> str:
        summaries: list[str] = []
        current_metrics = status.get("currentMetrics", []) or []
        metric_keys = {
            "Resource": "resource", "ContainerResource": "containerResource",
            "Pods": "pods", "Object": "object", "External": "external",
        }
        for index, metric in enumerate(spec.get("metrics", []) or []):
            metric_type = str(metric.get("type", "Unknown"))
            metric_key = metric_keys.get(metric_type, metric_type[:1].lower() + metric_type[1:])
            desired = metric.get(metric_key, {}) or {}
            target = desired.get("target", {}) or {}
            current_entry = current_metrics[index] if index < len(current_metrics) else {}
            current = (current_entry.get(metric_key, {}) or {}).get("current", {}) or {}
            name = str(desired.get("name") or (desired.get("metric", {}) or {}).get("name") or metric_type)
            target_value = target.get("averageUtilization") or target.get("averageValue") or target.get("value")
            current_value = current.get("averageUtilization") or current.get("averageValue") or current.get("value")
            summaries.append(f"{name}={current_value if current_value is not None else '?'} / {target_value if target_value is not None else '?'}")
        if not summaries and spec.get("targetCPUUtilizationPercentage") is not None:
            summaries.append(
                f"cpu={status.get('currentCPUUtilizationPercentage', '?')} / {spec.get('targetCPUUtilizationPercentage')}%"
            )
        return "; ".join(summaries) or "No HPA metric target returned"

    def sustained_utilization(self, app: str, project: str, datacenter: str) -> tuple[int, bool]:
        cfg = self.cfg.get("autoscaling", {})
        window = max(1, int(cfg.get("sustained_window_samples", 6)))
        minimum = max(2, int(cfg.get("sustained_min_high_samples", 3)))
        threshold = float(cfg.get("sustained_utilization_percent", 85))
        peaks: list[float] = []
        current = [
            max(row.cpu_request_utilization_percent or 0, row.memory_request_utilization_percent or 0)
            for row in self.performance_results
            if row.application == app and row.project == project and row.datacenter == datacenter
        ]
        if current:
            peaks.append(max(current))
        history_cfg = self.cfg.get("history", {})
        db_path = self.out_root / str(history_cfg.get("database_name", "ocp-health-history.db"))
        if history_cfg.get("enabled", True) and db_path.exists():
            try:
                with sqlite3.connect(db_path) as connection:
                    rows = connection.execute(
                        """SELECT run_id,
                                  MAX(COALESCE(cpu_request_utilization_percent, 0)),
                                  MAX(COALESCE(memory_request_utilization_percent, 0)),
                                  MAX(timestamp)
                           FROM performance_samples
                           WHERE application=? AND project=? AND datacenter=?
                           GROUP BY run_id ORDER BY MAX(timestamp) DESC LIMIT ?""",
                        (app, project, datacenter, window),
                    ).fetchall()
                peaks.extend(max(float(row[1] or 0), float(row[2] or 0)) for row in rows)
            except (sqlite3.Error, OSError) as exc:
                self.logger.write("WARN", "Historical utilization query failed.", project=project, error=str(exc))
        peaks = peaks[:window]
        sustained = len(peaks) >= minimum and all(value >= threshold for value in peaks[:minimum])
        return len(peaks), sustained

    def check_autoscaling_readiness(self, app: str, project: str):
        """Assess HPA/PDB/capacity readiness without changing cluster resources."""
        resources = [
            ("deployments.apps", "Deployment"),
            ("deploymentconfigs.apps.openshift.io", "DeploymentConfig"),
            ("statefulsets.apps", "StatefulSet"),
        ]
        workloads: dict[tuple[str, str], dict[str, Any]] = {}
        for resource, kind in resources:
            try:
                for item in self.oc_json(["get", resource, "-n", project]).get("items", []) or []:
                    name = str((item.get("metadata", {}) or {}).get("name", "unknown"))
                    workloads[(kind.lower(), name)] = item
            except Exception as exc:
                self.logger.write("WARN", "Autoscaling workload query failed.", project=project, resource=resource, error=str(exc))
        try:
            hpas = self.oc_json(["get", "hpa", "-n", project]).get("items", []) or []
        except Exception as exc:
            self.add(app, project, "AutoscalingReadiness", project, "Unknown", "QueryFailed", f"HPA query failed: {exc}")
            return
        try:
            pdbs = self.oc_json(["get", "poddisruptionbudgets.policy", "-n", project]).get("items", []) or []
        except Exception as exc:
            pdbs = []
            self.logger.write("WARN", "PDB query failed.", project=project, error=str(exc))
        try:
            pods = self.oc_json(["get", "pods", "-n", project]).get("items", []) or []
        except Exception as exc:
            pods = []
            self.logger.write("WARN", "Autoscaling pod query failed.", project=project, error=str(exc))
        try:
            events = self.oc_json(["get", "events", "-n", project]).get("items", []) or []
        except Exception:
            events = []
        node_labels: dict[str, dict[str, Any]] = {}
        try:
            for node in self.oc_json(["get", "nodes"]).get("items", []) or []:
                metadata = node.get("metadata", {}) or {}
                node_labels[str(metadata.get("name", ""))] = metadata.get("labels", {}) or {}
        except Exception:
            pass

        hpa_by_target: dict[tuple[str, str], dict[str, Any]] = {}
        for hpa in hpas:
            target = (hpa.get("spec", {}) or {}).get("scaleTargetRef", {}) or {}
            hpa_by_target[(str(target.get("kind", "")).lower(), str(target.get("name", "")))] = hpa
        targets = set(workloads) | set(hpa_by_target)
        scope_cfg = getattr(self.scope, "config", {}) or {}
        datacenter = str(scope_cfg.get("name", "default"))
        cluster = str(scope_cfg.get("cluster", self.cfg.get("cluster", {}).get("name", "unknown")))
        cfg = self.cfg.get("autoscaling", {})
        minimum_replicas = max(1, int(cfg.get("minimum_production_replicas", 2)))
        headroom_warning_percent = float(cfg.get("headroom_warning_percent", 20))
        repeated_event_threshold = max(1, int(cfg.get("repeated_scaling_event_threshold", 4)))
        minimum_nodes = max(1, int(cfg.get("minimum_nodes", 2)))
        minimum_zones = max(1, int(cfg.get("minimum_zones", 2)))
        missing_hpa_severity = str(cfg.get("missing_hpa_severity", "Warning"))
        missing_pdb_severity = str(cfg.get("missing_pdb_severity", "Warning"))
        sustained_samples, sustained_high = self.sustained_utilization(app, project, datacenter)

        for key in sorted(targets):
            kind_lower, name = key
            workload = workloads.get(key)
            hpa = hpa_by_target.get(key)
            kind = str(((hpa or {}).get("spec", {}) or {}).get("scaleTargetRef", {}).get("kind") or
                       (workload or {}).get("kind") or kind_lower)
            workload_name = f"{kind}/{name}"
            labels = (((workload or {}).get("spec", {}) or {}).get("template", {}) or {}).get("metadata", {}).get("labels", {}) or {}
            selector = self.workload_selector(workload or {})
            matching_pods = [
                pod for pod in pods
                if self.selector_matches((pod.get("metadata", {}) or {}).get("labels", {}) or {}, selector)
            ] if selector else []
            scheduled_nodes = {
                str((pod.get("spec", {}) or {}).get("nodeName"))
                for pod in matching_pods if (pod.get("spec", {}) or {}).get("nodeName")
            }
            zones = {
                str(node_labels.get(node, {}).get("topology.kubernetes.io/zone") or
                    node_labels.get(node, {}).get("failure-domain.beta.kubernetes.io/zone"))
                for node in scheduled_nodes
                if node_labels.get(node, {}).get("topology.kubernetes.io/zone") or
                   node_labels.get(node, {}).get("failure-domain.beta.kubernetes.io/zone")
            }
            unschedulable = 0
            for pod in matching_pods:
                if (pod.get("status", {}) or {}).get("phase") != "Pending":
                    continue
                conditions = (pod.get("status", {}) or {}).get("conditions", []) or []
                if any(c.get("type") == "PodScheduled" and c.get("status") == "False" and c.get("reason") == "Unschedulable" for c in conditions):
                    unschedulable += 1

            containers = (((workload or {}).get("spec", {}) or {}).get("template", {}) or {}).get("spec", {}).get("containers", []) or []
            requests_ready = bool(containers) and all(
                (container.get("resources", {}) or {}).get("requests", {}).get("cpu") and
                (container.get("resources", {}) or {}).get("requests", {}).get("memory")
                for container in containers
            )
            matched_pdbs = [
                pdb for pdb in pdbs
                if self.selector_matches(labels, (pdb.get("spec", {}) or {}).get("selector", {}) or {})
            ] if labels else []
            pdb_names = ", ".join(str((pdb.get("metadata", {}) or {}).get("name", "unknown")) for pdb in matched_pdbs)
            allowed_values = [int((pdb.get("status", {}) or {}).get("disruptionsAllowed", 0) or 0) for pdb in matched_pdbs]
            pdb_allowed = max(allowed_values) if allowed_values else None

            hpa_spec = (hpa or {}).get("spec", {}) or {}
            hpa_status = (hpa or {}).get("status", {}) or {}
            current = int(hpa_status.get("currentReplicas", ((workload or {}).get("status", {}) or {}).get("replicas", 0)) or 0)
            desired = int(hpa_status.get("desiredReplicas", current) or current)
            min_replicas = int(hpa_spec.get("minReplicas", 1) or 1) if hpa else current
            max_replicas = int(hpa_spec.get("maxReplicas", 0) or 0) if hpa else current
            headroom = max(0, max_replicas - max(current, desired)) if hpa else 0
            metric_summary = self.hpa_metric_summary(hpa_spec, hpa_status) if hpa else "HPA not configured"
            hpa_name = str(((hpa or {}).get("metadata", {}) or {}).get("name", "(none)"))
            scale_events = sum(
                1 for event in events
                if str((event.get("reason") or "")).lower() in {"successfulrescale", "scalingreplicaset"}
                and (hpa_name == "(none)" or str((event.get("involvedObject", {}) or {}).get("name", "")) == hpa_name)
            )

            severity, recommendations = "Healthy", []
            def flag(level: str, message: str):
                nonlocal severity
                if level == "Critical" or (level == "Warning" and severity not in {"Critical"}):
                    severity = level
                recommendations.append(message)

            if not hpa:
                flag(missing_hpa_severity, "Configure an HPA or document why this workload uses fixed replicas.")
            elif workload is None:
                flag("Critical", "Fix the HPA scale target; the referenced workload was not found.")
            if hpa and min_replicas < minimum_replicas:
                flag("Warning", f"Set/validate minimum replicas for production availability (standard: {minimum_replicas}).")
            if hpa and max_replicas <= max(current, desired):
                flag("Critical", "Increase or validate HPA maximum replicas and cluster capacity; no scaling headroom remains.")
            elif hpa and max_replicas and (headroom / max_replicas * 100) <= headroom_warning_percent:
                flag("Warning", "Review HPA maximum replicas; remaining scaling headroom is low.")
            if not requests_ready:
                flag("Critical" if hpa else "Warning", "Add CPU and memory requests to every workload container so utilization and HPA metrics are reliable.")
            if not matched_pdbs and current >= minimum_replicas:
                flag(missing_pdb_severity, "Add a PodDisruptionBudget to protect availability during voluntary disruptions.")
            elif matched_pdbs and pdb_allowed == 0 and current >= minimum_replicas:
                flag("Warning", "Review the PDB because it currently allows zero voluntary disruptions.")
            if unschedulable:
                flag("Critical", "Resolve unschedulable pods and verify node quota, taints, affinity and cluster capacity.")
            if current >= minimum_replicas and len(scheduled_nodes) < minimum_nodes:
                flag("Warning", f"Spread replicas across at least {minimum_nodes} nodes.")
            if zones and current >= minimum_replicas and len(zones) < minimum_zones:
                flag("Warning", f"Spread replicas across at least {minimum_zones} zones where the cluster supports zones.")
            if scale_events >= repeated_event_threshold:
                flag("Warning", "Review repeated scaling activity for oscillation and tune stabilization/targets.")
            if sustained_high:
                flag("Critical" if hpa and headroom == 0 else "Warning", "Review sustained high utilization using p95/p99 history and validate requests, limits and HPA targets.")
            for condition in hpa_status.get("conditions", []) or []:
                if condition.get("type") in {"AbleToScale", "ScalingActive"} and condition.get("status") == "False":
                    flag("Critical", f"Resolve HPA condition {condition.get('type')}={condition.get('reason', 'False')}.")

            result = AutoscalingReadinessResult(
                timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"), run_id=self.run_id,
                datacenter=datacenter, cluster=cluster, application=app, project=project,
                workload=workload_name, hpa=hpa_name, current_replicas=current,
                desired_replicas=desired, min_replicas=min_replicas, max_replicas=max_replicas,
                scaling_headroom=headroom, metric_vs_target=metric_summary,
                target_exists=workload is not None, resource_requests_ready=requests_ready,
                pdb=pdb_names or "(none)", pdb_allowed_disruptions=pdb_allowed,
                unschedulable_pods=unschedulable, nodes=len(scheduled_nodes), zones=len(zones),
                recent_scaling_events=scale_events, sustained_samples=sustained_samples,
                sustained_high_utilization=sustained_high, severity=severity,
                status="Ready" if severity == "Healthy" else "Attention",
                recommendation=" ".join(dict.fromkeys(recommendations)) or "Autoscaling and disruption controls are ready.",
            )
            with self.autoscaling_lock:
                self.autoscaling_results.append(result)
            self.add(app, project, "AutoscalingReadiness", workload_name, severity, result.status,
                     f"HPA={hpa_name}; Replicas={current}/{desired}; Min/Max={min_replicas}/{max_replicas}; "
                     f"Headroom={headroom}; PDB={result.pdb}; Metrics={metric_summary}; {result.recommendation}")

        if not targets:
            self.add(app, project, "AutoscalingReadiness", "(none)", "Unknown", "NoScalableWorkloads",
                     "No Deployment, DeploymentConfig, StatefulSet or HPA was returned for readiness assessment.")

    def capacity_results(self) -> list[CapacityResult]:
        perf_cfg = self.cfg.get("performance", {})
        target_util = max(1.0, float(perf_cfg.get("target_utilization_percent", 80)))
        limit_multiplier = max(1.0, float(perf_cfg.get("limit_multiplier", 1.5)))
        groups: dict[tuple[str, str, str, str, str], list[PerformanceResult]] = {}
        for row in self.performance_results:
            key = (row.datacenter, row.cluster, row.application, row.project, row.workload)
            groups.setdefault(key, []).append(row)
        results: list[CapacityResult] = []
        for key, rows in sorted(groups.items()):
            dc, cluster, app, project, workload = key
            current = len(rows)
            target = next((r.target_pods for r in rows if r.target_pods > 0), current) or current
            observed_cpu = sum(r.cpu_usage_cores for r in rows)
            observed_memory = sum(r.memory_usage_mib for r in rows)
            cpu_request = observed_cpu / target / (target_util / 100.0) if target else 0.0
            memory_request = observed_memory / target / (target_util / 100.0) if target else 0.0
            results.append(CapacityResult(
                dc, cluster, app, project, workload, current, target,
                round(observed_cpu, 6), round(observed_memory, 2),
                round(cpu_request, 3), round(cpu_request * limit_multiplier, 3),
                round(memory_request, 1), round(memory_request * limit_multiplier, 1),
                target_util, limit_multiplier,
                "snapshot total usage / target pods / target utilization",
            ))
        return results

    def check_events(self, app: str, project: str):
        try: items=self.oc_json(["get","events","-n",project,"--field-selector","type=Warning"]).get("items",[])
        except Exception as e:
            self.logger.write("WARN","Event query failed.",project=project,error=str(e)); return
        window=int(self.cfg["execution"].get("warning_event_window_minutes",60))
        for x in items:
            ts=x.get("eventTime") or x.get("lastTimestamp") or x.get("metadata",{}).get("creationTimestamp")
            if not ts: continue
            try:
                if self.age_minutes(ts)>window: continue
            except Exception: continue
            self.add(app,project,"WarningEvent",str(x.get("involvedObject",{}).get("name","unknown")),
                     "Warning",str(x.get("reason","Warning")),str(x.get("message","")))

    def application_summary(self):
        data={}
        for r in self.results:
            d=data.setdefault(r.application,{"Critical":0,"Warning":0,"Healthy":0,"Unknown":0})
            d[r.severity]=d.get(r.severity,0)+1
        for app, counts in data.items():
            penalty = counts.get("Critical",0)*25 + counts.get("Warning",0)*8 + counts.get("Unknown",0)*5
            counts["HealthScore"] = max(0, 100-penalty)
            counts["State"] = "Critical" if counts.get("Critical",0) else ("Warning" if counts.get("Warning",0) else ("Unknown" if counts.get("Unknown",0) else "Healthy"))
        return data

    def write_reports(self):
        order={"Critical":0,"Warning":1,"Unknown":2,"Healthy":3}
        rows=sorted(self.results,key=lambda r:(order.get(r.severity,9),r.application,r.project,r.resource_type,r.resource_name))
        fields=list(Result.__dataclass_fields__)
        with (self.run_dir/"ocp-health.csv").open("w",newline="",encoding="utf-8-sig") as f:
            w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(asdict(r) for r in rows)
        (self.run_dir/"ocp-health.json").write_text(json.dumps([asdict(r) for r in rows],indent=2),encoding="utf-8")
        clusters=sorted({r.cluster for r in rows})
        datacenters=sorted({r.datacenter for r in rows})
        summary={"run_id":self.run_id,"cluster":clusters[0] if len(clusters)==1 else "multiple-clusters",
                 "clusters":clusters,"datacenters":datacenters,"generated_at":datetime.now(timezone.utc).isoformat(),
                 "healthy":sum(r.severity=="Healthy" for r in rows),"warning":sum(r.severity=="Warning" for r in rows),
                 "critical":sum(r.severity=="Critical" for r in rows),"unknown":sum(r.severity=="Unknown" for r in rows),
                 "total":len(rows),"performance_rows":len(self.performance_results),
                 "autoscaling_rows":len(self.autoscaling_results),
                 "application_summary":self.application_summary(),"report_directory":str(self.run_dir)}
        (self.run_dir/"summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
        appcards="".join(f"<tr><td>{html.escape(a)}</td><td>{c['HealthScore']}%</td><td>{c['State']}</td><td>{c['Critical']}</td><td>{c['Warning']}</td><td>{c['Healthy']}</td><td>{c['Unknown']}</td></tr>" for a,c in sorted(summary["application_summary"].items()))
        detail="".join("<tr class='"+r.severity.lower()+"'>"+"".join(f"<td>{html.escape(str(v))}</td>" for v in [r.datacenter,r.cluster,r.application,r.project,r.resource_type,r.resource_name,r.severity,r.status,r.details])+"</tr>" for r in rows)
        doc=f"""<!doctype html><html><head><meta charset='utf-8'><title>OCP Health</title><style>
body{{font-family:Segoe UI,Arial;margin:24px;color:#202124}}.cards{{display:flex;gap:12px;margin:16px 0;flex-wrap:wrap}}
.card{{padding:14px;border:1px solid #ccc;border-radius:8px;font-weight:600}}.critical{{background:#fde7e7}}.warning{{background:#fff4ce}}.healthy{{background:#e6f4ea}}.unknown{{background:#edf1f7}}
table{{border-collapse:collapse;width:100%;font-size:13px;margin-bottom:22px}}th,td{{border:1px solid #ccc;padding:7px;text-align:left;vertical-align:top}}th{{background:#f1f3f4;position:sticky;top:0}}</style></head><body>
<h1>OCP Application Health Report</h1><p>Datacenters: {html.escape(', '.join(datacenters))} | Cluster scope: {html.escape(str(summary['cluster']))} | Run: {self.run_id} | Generated: {summary['generated_at']}</p>
<div class='cards'><div class='card critical'>Critical: {summary['critical']}</div><div class='card warning'>Warning: {summary['warning']}</div><div class='card healthy'>Healthy: {summary['healthy']}</div><div class='card unknown'>Unknown: {summary['unknown']}</div></div>
<h2>Application Summary</h2><table><tr><th>Application</th><th>Health Score</th><th>State</th><th>Critical</th><th>Warning</th><th>Healthy</th><th>Unknown</th></tr>{appcards}</table>
<h2>Resource Details</h2><table><tr><th>Datacenter</th><th>Cluster</th><th>Application</th><th>Project</th><th>Resource</th><th>Name</th><th>Severity</th><th>Status</th><th>Details</th></tr>{detail}</table></body></html>"""
        (self.run_dir/"ocp-health.html").write_text(doc,encoding="utf-8")
        self.write_performance_reports(summary)
        return summary

    def write_performance_reports(self, summary: dict[str, Any]):
        perf_rows = sorted(
            self.performance_results,
            key=lambda r: (r.datacenter, r.application, r.project, r.workload, r.pod),
        )
        capacity_rows = self.capacity_results()
        autoscaling_rows = sorted(
            self.autoscaling_results,
            key=lambda r: (r.datacenter, r.application, r.project, r.workload),
        )

        def write_csv_json(stem: str, values: list[Any], dataclass_type: Any):
            fields = list(dataclass_type.__dataclass_fields__)
            with (self.run_dir / f"{stem}.csv").open("w", newline="", encoding="utf-8-sig") as handle:
                writer = csv.DictWriter(handle, fieldnames=fields)
                writer.writeheader()
                writer.writerows(asdict(value) for value in values)
            (self.run_dir / f"{stem}.json").write_text(
                json.dumps([asdict(value) for value in values], indent=2), encoding="utf-8"
            )

        write_csv_json("ocp-performance", perf_rows, PerformanceResult)
        write_csv_json("ocp-capacity-recommendations", capacity_rows, CapacityResult)
        write_csv_json("ocp-autoscaling-readiness", autoscaling_rows, AutoscalingReadinessResult)

        performance_body = "".join(
            "<tr class='" + row.severity.lower() + "'>" + "".join(
                f"<td>{html.escape('' if value is None else str(value))}</td>"
                for value in [
                    row.datacenter, row.application, row.project, row.workload, row.pod,
                    row.cpu_usage_cores, row.cpu_request_utilization_percent,
                    row.memory_usage_mib, row.memory_request_utilization_percent,
                    row.severity, row.finding,
                ]
            ) + "</tr>" for row in perf_rows
        )
        capacity_body = "".join(
            "<tr>" + "".join(f"<td>{html.escape(str(value))}</td>" for value in [
                row.datacenter, row.application, row.project, row.workload,
                row.current_pods, row.target_pods, row.observed_cpu_cores,
                row.recommended_cpu_request_per_pod, row.recommended_cpu_limit_per_pod,
                row.observed_memory_mib, row.recommended_memory_request_mib_per_pod,
                row.recommended_memory_limit_mib_per_pod,
            ]) + "</tr>" for row in capacity_rows
        )
        perf_doc = f"""<!doctype html><html><head><meta charset='utf-8'><title>OCP Performance</title><style>
body{{font-family:Segoe UI,Arial;margin:24px;color:#202124}}table{{border-collapse:collapse;width:100%;font-size:12px;margin-bottom:24px}}
th,td{{border:1px solid #ccc;padding:7px;text-align:left}}th{{background:#f1f3f4;position:sticky;top:0}}.critical{{background:#fde7e7}}.warning{{background:#fff4ce}}.healthy{{background:#e6f4ea}}.unknown{{background:#edf1f7}}</style></head><body>
<h1>OCP Application Performance &amp; Capacity Report</h1>
<p>Run: {html.escape(self.run_id)} | Generated: {html.escape(str(summary['generated_at']))}</p>
<p><b>Calculation:</b> total observed workload usage ÷ target pods ÷ target utilisation. Limits are the configured multiplier of requests. This is a live snapshot; use scheduled history or Prometheus/Thanos p95 data for production sizing decisions.</p>
<h2>Pod Performance</h2><table><tr><th>Datacenter</th><th>Application</th><th>Project</th><th>Workload</th><th>Pod</th><th>CPU cores</th><th>CPU % request</th><th>Memory MiB</th><th>Memory % request</th><th>Severity</th><th>Finding</th></tr>{performance_body}</table>
<h2>Capacity Recommendations</h2><table><tr><th>Datacenter</th><th>Application</th><th>Project</th><th>Workload</th><th>Current pods</th><th>Target pods</th><th>Observed CPU</th><th>CPU request/pod</th><th>CPU limit/pod</th><th>Observed memory MiB</th><th>Memory request/pod MiB</th><th>Memory limit/pod MiB</th></tr>{capacity_body}</table>
</body></html>"""
        (self.run_dir / "ocp-performance.html").write_text(perf_doc, encoding="utf-8")
        autoscaling_body = "".join(
            "<tr class='" + row.severity.lower() + "'>" + "".join(
                f"<td>{html.escape('' if value is None else str(value))}</td>"
                for value in [
                    row.datacenter, row.application, row.project, row.workload, row.hpa,
                    f"{row.current_replicas}/{row.desired_replicas}",
                    f"{row.min_replicas}/{row.max_replicas}", row.metric_vs_target,
                    row.scaling_headroom, row.pdb, row.pdb_allowed_disruptions,
                    row.unschedulable_pods, row.nodes, row.zones,
                    row.recent_scaling_events, row.sustained_high_utilization,
                    row.severity, row.recommendation,
                ]
            ) + "</tr>" for row in autoscaling_rows
        )
        autoscaling_doc = f"""<!doctype html><html><head><meta charset='utf-8'><title>OCP Autoscaling Readiness</title><style>
body{{font-family:Segoe UI,Arial;margin:24px;color:#202124}}table{{border-collapse:collapse;width:100%;font-size:12px}}
th,td{{border:1px solid #ccc;padding:7px;text-align:left;vertical-align:top}}th{{background:#f1f3f4;position:sticky;top:0}}.critical{{background:#fde7e7}}.warning{{background:#fff4ce}}.healthy{{background:#e6f4ea}}.unknown{{background:#edf1f7}}</style></head><body>
<h1>OCP Autoscaling Readiness Report</h1><p>Run: {html.escape(self.run_id)} | Generated: {html.escape(str(summary['generated_at']))}</p>
<p>This is a read-only assessment. It does not scale, patch, restart or delete resources.</p>
<table><tr><th>Datacenter</th><th>Application</th><th>Project</th><th>Workload</th><th>HPA</th><th>Current/Desired</th><th>Min/Max</th><th>Metric vs Target</th><th>Headroom</th><th>PDB</th><th>Allowed Disruptions</th><th>Unschedulable</th><th>Nodes</th><th>Zones</th><th>Recent Scale Events</th><th>Sustained High</th><th>Status</th><th>Recommendation</th></tr>{autoscaling_body}</table>
</body></html>"""
        (self.run_dir / "ocp-autoscaling-readiness.html").write_text(autoscaling_doc, encoding="utf-8")
        self.write_excel(summary, perf_rows, capacity_rows, autoscaling_rows)

    def write_excel(self, summary: dict[str, Any], perf_rows: list[PerformanceResult],
                    capacity_rows: list[CapacityResult],
                    autoscaling_rows: list[AutoscalingReadinessResult]):
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Alignment, Font, PatternFill
            from openpyxl.utils import get_column_letter
        except ImportError:
            self.logger.write("WARN", "Excel report skipped; install openpyxl from requirements.txt.")
            return

        workbook = Workbook()
        workbook.remove(workbook.active)
        header_fill = PatternFill("solid", fgColor="1F4E78")
        header_font = Font(color="FFFFFF", bold=True)
        severity_fill = {
            "Critical": PatternFill("solid", fgColor="F4CCCC"),
            "Warning": PatternFill("solid", fgColor="FFF2CC"),
            "Healthy": PatternFill("solid", fgColor="D9EAD3"),
            "Unknown": PatternFill("solid", fgColor="D9E2F3"),
        }

        def add_sheet(name: str, records: list[dict[str, Any]], severity_column: str | None = None):
            sheet = workbook.create_sheet(name)
            if not records:
                sheet.append(["No data returned"])
                return
            headers = list(records[0])
            sheet.append(headers)
            for cell in sheet[1]:
                cell.fill, cell.font, cell.alignment = header_fill, header_font, Alignment(wrap_text=True)
            for record in records:
                sheet.append([record.get(header) for header in headers])
                if severity_column and severity_column in headers:
                    severity = str(record.get(severity_column, ""))
                    fill = severity_fill.get(severity)
                    if fill:
                        for cell in sheet[sheet.max_row]:
                            cell.fill = fill
            sheet.freeze_panes = "A2"
            sheet.auto_filter.ref = sheet.dimensions
            for index, header in enumerate(headers, 1):
                max_len = max(len(str(header)), *(len(str(record.get(header, ""))) for record in records))
                sheet.column_dimensions[get_column_letter(index)].width = min(max(max_len + 2, 12), 42)
            for row in sheet.iter_rows():
                for cell in row:
                    cell.alignment = Alignment(vertical="top", wrap_text=True)

        summary_records = [{
            "run_id": summary["run_id"],
            "generated_at": summary["generated_at"],
            "datacenters": ", ".join(summary.get("datacenters", [])),
            "clusters": ", ".join(summary.get("clusters", [])),
            "critical": summary["critical"],
            "warning": summary["warning"],
            "healthy": summary["healthy"],
            "unknown": summary["unknown"],
            "performance_rows": summary.get("performance_rows", 0),
            "autoscaling_rows": summary.get("autoscaling_rows", 0),
        }]
        add_sheet("Run Summary", summary_records)
        add_sheet("Pod Performance", [asdict(row) for row in perf_rows], "severity")
        add_sheet("Capacity Recommendations", [asdict(row) for row in capacity_rows])
        add_sheet("Autoscaling Readiness", [asdict(row) for row in autoscaling_rows], "severity")
        add_sheet("Health Findings", [asdict(row) for row in self.results], "severity")
        workbook.save(self.run_dir / "ocp-performance.xlsx")

    def issue_category(self, result: Result) -> str:
        text = f"{result.resource_type} {result.status} {result.details}".lower()

        if result.resource_type == "Pod":
            if "crashloopbackoff" in text:
                return "CrashLoopBackOff"
            if "imagepullbackoff" in text or "errimagepull" in text:
                return "Image pull failure"
            if "oomkilled" in text:
                return "OOMKilled"
            if "not ready" in text or "ready=false" in text:
                return "Pod not ready"
            if "pending" in text:
                return "Pod pending"
            return "Unhealthy pod"

        if result.resource_type in {"Deployment", "DeploymentConfig", "StatefulSet", "DaemonSet"}:
            return f"{result.resource_type} unavailable"

        if result.resource_type == "Service":
            if "noreadyendpoints" in text or "readyendpointaddresses=0" in text:
                return "Service has no ready endpoints"
            return "Service issue"

        if result.resource_type == "Route":
            if "notadmitted" in text:
                return "Route not admitted"
            if "nohost" in text:
                return "Route host missing"
            return "Route issue"

        if result.resource_type == "PVC":
            return "PVC not bound"

        if result.resource_type in {"HPA", "AutoscalingReadiness"}:
            return "Autoscaling issue"

        if result.resource_type == "ResourceQuota":
            return "Quota usage high"

        if result.resource_type == "LimitRange":
            return "LimitRange missing"

        if result.resource_type == "WarningEvent":
            reason = result.status.strip() or "Warning event"
            return reason

        if result.resource_type == "PodMetrics":
            return "Metrics unavailable"

        if result.resource_type == "PodPerformance":
            if result.status == "Unavailable":
                return "Performance metrics unavailable"
            return "Resource utilization outside threshold"

        if result.resource_type == "Project":
            return "Project unavailable"

        return f"{result.resource_type} issue"

    def recommended_action(self, result: Result) -> str:
        text = f"{result.status} {result.details}".lower()

        if result.resource_type == "Pod":
            if "crashloopbackoff" in text:
                return "Review current and previous container logs; inspect pod events and recent configuration changes."
            if "imagepullbackoff" in text or "errimagepull" in text:
                return "Verify image name/tag, registry reachability, pull secret and image permissions."
            if "oomkilled" in text:
                return "Review memory usage and container limits; check for memory leaks before increasing limits."
            if "pending" in text:
                return "Describe the pod and review scheduling, quota, PVC and node-capacity events."
            return "Describe the pod, review readiness/liveness probes and inspect container logs."

        if result.resource_type in {"Deployment", "DeploymentConfig", "StatefulSet", "DaemonSet"}:
            return "Check rollout status, related ReplicaSets/pods and recent warning events."

        if result.resource_type == "Service":
            return "Verify service selector labels match running pods and confirm endpoint addresses are created."

        if result.resource_type == "Route":
            return "Review route admission, router status, host configuration and target service."

        if result.resource_type == "PVC":
            return "Check storage class, provisioner events, access mode, requested capacity and available storage."

        if result.resource_type == "HPA":
            return "Review HPA conditions, metrics availability, target utilisation and maximum replica limit."

        if result.resource_type == "AutoscalingReadiness":
            return "Review the Autoscaling Readiness sheet for HPA target/headroom, resource requests, PDB protection, replica spread and sustained utilization."

        if result.resource_type == "ResourceQuota":
            return "Identify the exhausted quota resource and reduce usage or request an approved quota increase."

        if result.resource_type == "WarningEvent":
            if "failedcreate" in text:
                return "Review the owning controller, quota, admission-policy and scheduling event details."
            if "failedgetscale" in text:
                return "Verify the HPA scale target exists and the metrics/scale APIs are available."
            if "backoff" in text:
                return "Inspect the affected pod logs and restart history to identify the repeated failure."
            if "unhealthy" in text:
                return "Review readiness/liveness probe failures and application endpoint response."
            return "Review the involved object and event message, then correlate with pod/controller status."

        if result.resource_type == "PodPerformance":
            return "Review CPU/memory usage against requests and limits; validate sustained p95 usage before applying the attached capacity recommendation."

        if result.resource_type == "Project":
            return "Verify project name, RBAC access and cluster connectivity."

        return "Review the attached detailed report and inspect the affected OpenShift resource."

    def cli_commands(self, result: Result) -> list[str]:
        project = result.project
        name = result.resource_name

        if result.resource_type == "Pod":
            return [
                f"oc describe pod {name} -n {project}",
                f"oc logs {name} -n {project} --all-containers=true --tail=200",
                f"oc logs {name} -n {project} --all-containers=true --previous --tail=200",
            ]

        if result.resource_type == "AutoscalingReadiness":
            workload_kind, _, workload_name = name.partition("/")
            resource = {
                "Deployment": "deployment", "DeploymentConfig": "deploymentconfig",
                "StatefulSet": "statefulset",
            }.get(workload_kind, "all")
            commands = [
                f"oc get hpa -n {project} -o wide",
                f"oc get poddisruptionbudget -n {project}",
                f"oc get pods -n {project} -o wide",
            ]
            if workload_name and resource != "all":
                commands.insert(0, f"oc describe {resource} {workload_name} -n {project}")
            return commands

        resource_map = {
            "Deployment": "deployment",
            "DeploymentConfig": "deploymentconfig",
            "StatefulSet": "statefulset",
            "DaemonSet": "daemonset",
            "Service": "service",
            "Route": "route",
            "PVC": "pvc",
            "HPA": "hpa",
            "ReplicaSet": "replicaset",
            "ResourceQuota": "resourcequota",
            "LimitRange": "limitrange",
        }

        if result.resource_type in resource_map:
            resource = resource_map[result.resource_type]
            return [
                f"oc get {resource} {name} -n {project} -o wide",
                f"oc describe {resource} {name} -n {project}",
                f"oc get events -n {project} --sort-by=.lastTimestamp",
            ]

        if result.resource_type == "WarningEvent":
            return [
                f"oc describe {name} -n {project}",
                f"oc get events -n {project} --sort-by=.lastTimestamp",
            ]

        return [
            f"oc get all -n {project}",
            f"oc get events -n {project} --sort-by=.lastTimestamp",
        ]

    def build_exception_email_html(self, summary: dict[str, Any]) -> str:
        notification = self.cfg.get("notifications", {})
        max_rows = int(notification.get("max_issue_rows", 25))
        max_commands = int(notification.get("max_command_sections", 8))

        email_severities = set(notification.get("email_severities", ["Critical"]))
        exceptions = [
            result for result in self.results
            if result.severity in email_severities
        ]

        severity_order = {"Critical": 0, "Warning": 1}
        exceptions.sort(
            key=lambda r: (
                severity_order.get(r.severity, 9),
                r.application,
                r.project,
                r.resource_type,
                r.resource_name,
            )
        )

        grouped: dict[tuple[str, str, str, str, str], int] = {}
        representative: dict[tuple[str, str, str, str, str], Result] = {}

        for result in exceptions:
            category = self.issue_category(result)
            key = (result.severity, result.datacenter, result.application, result.project, category)
            grouped[key] = grouped.get(key, 0) + 1
            representative.setdefault(key, result)

        grouped_rows = []
        for key, count in sorted(
            grouped.items(),
            key=lambda item: (
                severity_order.get(item[0][0], 9),
                item[0][1], item[0][2], item[0][3], item[0][4],
            ),
        )[:max_rows]:
            severity, datacenter, application, project, category = key
            sample = representative[key]
            background = "#fde7e7" if severity == "Critical" else "#fff4ce"
            grouped_rows.append(
                "<tr>"
                f"<td style='border:1px solid #ccc;padding:7px;background:{background}'><b>{html.escape(severity)}</b></td>"
                f"<td style='border:1px solid #ccc;padding:7px'>{html.escape(datacenter)}</td>"
                f"<td style='border:1px solid #ccc;padding:7px'>{html.escape(application)}</td>"
                f"<td style='border:1px solid #ccc;padding:7px'>{html.escape(project)}</td>"
                f"<td style='border:1px solid #ccc;padding:7px'>{html.escape(category)}</td>"
                f"<td style='border:1px solid #ccc;padding:7px;text-align:center'>{count}</td>"
                f"<td style='border:1px solid #ccc;padding:7px'>{html.escape(self.recommended_action(sample))}</td>"
                "</tr>"
            )

        critical_details = []
        for result in exceptions:
            if result.severity != "Critical":
                continue
            critical_details.append(
                "<tr>"
                f"<td style='border:1px solid #ccc;padding:7px'>{html.escape(result.datacenter)}</td>"
                f"<td style='border:1px solid #ccc;padding:7px'>{html.escape(result.application)}</td>"
                f"<td style='border:1px solid #ccc;padding:7px'>{html.escape(result.project)}</td>"
                f"<td style='border:1px solid #ccc;padding:7px'>{html.escape(result.resource_type)}</td>"
                f"<td style='border:1px solid #ccc;padding:7px'>{html.escape(result.resource_name)}</td>"
                f"<td style='border:1px solid #ccc;padding:7px'>{html.escape(result.status)}</td>"
                f"<td style='border:1px solid #ccc;padding:7px'>{html.escape(result.details)}</td>"
                "</tr>"
            )
            if len(critical_details) >= max_rows:
                break

        command_sections = []
        seen_projects: set[tuple[str, str, str]] = set()
        for result in exceptions:
            key = (result.datacenter, result.project, result.resource_name)
            if key in seen_projects:
                continue
            seen_projects.add(key)
            commands = self.cli_commands(result)
            command_text = "\n".join(commands)
            command_sections.append(
                f"<p><b>{html.escape(result.datacenter)} — {html.escape(result.application)} — {html.escape(result.project)} — "
                f"{html.escape(result.resource_name)}</b></p>"
                f"<pre style='background:#f5f5f5;border:1px solid #ddd;padding:10px;"
                f"white-space:pre-wrap'>{html.escape(command_text)}</pre>"
            )
            if len(command_sections) >= max_commands:
                break

        overall_status = "CRITICAL" if any(r.severity == "Critical" for r in exceptions) else (
            "WARNING" if any(r.severity == "Warning" for r in exceptions) else "HEALTHY"
        )
        banner = "#b3261e" if overall_status == "CRITICAL" else ("#8a5d00" if overall_status == "WARNING" else "#137333")

        if grouped_rows:
            issue_summary = f"""
            <h3>Issues requiring attention</h3>
            <table style="border-collapse:collapse;width:100%;font-size:13px">
              <tr style="background:#f1f3f4">
                <th style="border:1px solid #ccc;padding:7px;text-align:left">Severity</th>
                <th style="border:1px solid #ccc;padding:7px;text-align:left">Datacenter</th>
                <th style="border:1px solid #ccc;padding:7px;text-align:left">Application</th>
                <th style="border:1px solid #ccc;padding:7px;text-align:left">Project</th>
                <th style="border:1px solid #ccc;padding:7px;text-align:left">Issue</th>
                <th style="border:1px solid #ccc;padding:7px;text-align:center">Affected</th>
                <th style="border:1px solid #ccc;padding:7px;text-align:left">Recommended action</th>
              </tr>
              {''.join(grouped_rows)}
            </table>
            """
        else:
            issue_summary = "<p>No critical or warning exceptions were detected.</p>"

        critical_section = ""
        if critical_details:
            critical_section = f"""
            <h3>Critical resource details</h3>
            <table style="border-collapse:collapse;width:100%;font-size:13px">
              <tr style="background:#f1f3f4">
                <th style="border:1px solid #ccc;padding:7px;text-align:left">Datacenter</th>
                <th style="border:1px solid #ccc;padding:7px;text-align:left">Application</th>
                <th style="border:1px solid #ccc;padding:7px;text-align:left">Project</th>
                <th style="border:1px solid #ccc;padding:7px;text-align:left">Resource</th>
                <th style="border:1px solid #ccc;padding:7px;text-align:left">Name</th>
                <th style="border:1px solid #ccc;padding:7px;text-align:left">Status</th>
                <th style="border:1px solid #ccc;padding:7px;text-align:left">Details</th>
              </tr>
              {''.join(critical_details)}
            </table>
            """

        commands_section = ""
        if bool(notification.get("include_cli_commands", True)) and command_sections:
            commands_section = (
                "<h3>Suggested troubleshooting commands</h3>"
                "<p>Run only after confirming the correct production project and following change/support procedures.</p>"
                + "".join(command_sections)
            )

        return f"""
        <html>
        <body style="font-family:Segoe UI,Arial,sans-serif;color:#202124">
          <div style="background:{banner};color:white;padding:14px 18px">
            <h2 style="margin:0">OCP Production Health — {overall_status}</h2>
          </div>

          <p>
            <b>Cluster:</b> {html.escape(str(summary['cluster']))}<br>
            <b>Run ID:</b> {html.escape(str(summary['run_id']))}<br>
            <b>Generated:</b> {html.escape(str(summary['generated_at']))}
          </p>

          {issue_summary}
          {critical_section}
          {commands_section}
          <p>The detailed health and performance reports are attached.</p>
        </body>
        </html>
        """

    def persist_history(self, summary: dict[str, Any]):
        history_cfg = self.cfg.get("history", {})
        if not history_cfg.get("enabled", True):
            return
        db_path = self.out_root / str(history_cfg.get("database_name", "ocp-health-history.db"))
        with sqlite3.connect(db_path) as conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS runs (
                run_id TEXT PRIMARY KEY, generated_at TEXT, cluster TEXT,
                critical INTEGER, warning INTEGER, healthy INTEGER, unknown INTEGER, total INTEGER
            )""")
            conn.execute("""CREATE TABLE IF NOT EXISTS application_runs (
                run_id TEXT, application TEXT, health_score INTEGER, state TEXT,
                critical INTEGER, warning INTEGER, healthy INTEGER, unknown INTEGER,
                PRIMARY KEY (run_id, application)
            )""")
            conn.execute("""CREATE TABLE IF NOT EXISTS performance_samples (
                run_id TEXT, timestamp TEXT, datacenter TEXT, cluster TEXT,
                application TEXT, project TEXT, workload TEXT, pod TEXT,
                cpu_usage_cores REAL, cpu_request_utilization_percent REAL,
                memory_usage_mib REAL, memory_request_utilization_percent REAL,
                severity TEXT, finding TEXT,
                PRIMARY KEY (run_id, datacenter, project, pod)
            )""")
            conn.execute("""CREATE TABLE IF NOT EXISTS capacity_recommendations (
                run_id TEXT, datacenter TEXT, cluster TEXT, application TEXT,
                project TEXT, workload TEXT, current_pods INTEGER, target_pods INTEGER,
                observed_cpu_cores REAL, observed_memory_mib REAL,
                recommended_cpu_request_per_pod REAL, recommended_cpu_limit_per_pod REAL,
                recommended_memory_request_mib_per_pod REAL,
                recommended_memory_limit_mib_per_pod REAL,
                target_utilization_percent REAL, limit_multiplier REAL,
                PRIMARY KEY (run_id, datacenter, project, workload)
            )""")
            conn.execute("""CREATE TABLE IF NOT EXISTS autoscaling_readiness (
                run_id TEXT, timestamp TEXT, datacenter TEXT, cluster TEXT,
                application TEXT, project TEXT, workload TEXT, hpa TEXT,
                current_replicas INTEGER, desired_replicas INTEGER,
                min_replicas INTEGER, max_replicas INTEGER, scaling_headroom INTEGER,
                metric_vs_target TEXT, target_exists INTEGER,
                resource_requests_ready INTEGER, pdb TEXT,
                pdb_allowed_disruptions INTEGER, unschedulable_pods INTEGER,
                nodes INTEGER, zones INTEGER, recent_scaling_events INTEGER,
                sustained_samples INTEGER, sustained_high_utilization INTEGER,
                severity TEXT, status TEXT, recommendation TEXT,
                PRIMARY KEY (run_id, datacenter, project, workload)
            )""")
            conn.execute("INSERT OR REPLACE INTO runs VALUES (?,?,?,?,?,?,?,?)", (
                summary["run_id"], summary["generated_at"], summary["cluster"], summary["critical"],
                summary["warning"], summary["healthy"], summary["unknown"], summary["total"]))
            for app, counts in summary["application_summary"].items():
                conn.execute("INSERT OR REPLACE INTO application_runs VALUES (?,?,?,?,?,?,?,?)", (
                    summary["run_id"], app, counts["HealthScore"], counts["State"], counts["Critical"],
                    counts["Warning"], counts["Healthy"], counts["Unknown"]))
            for row in self.performance_results:
                conn.execute("INSERT OR REPLACE INTO performance_samples VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (
                    row.run_id, row.timestamp, row.datacenter, row.cluster, row.application,
                    row.project, row.workload, row.pod, row.cpu_usage_cores,
                    row.cpu_request_utilization_percent, row.memory_usage_mib,
                    row.memory_request_utilization_percent, row.severity, row.finding,
                ))
            for row in self.capacity_results():
                conn.execute("INSERT OR REPLACE INTO capacity_recommendations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (
                    summary["run_id"], row.datacenter, row.cluster, row.application, row.project,
                    row.workload, row.current_pods, row.target_pods, row.observed_cpu_cores,
                    row.observed_memory_mib, row.recommended_cpu_request_per_pod,
                    row.recommended_cpu_limit_per_pod, row.recommended_memory_request_mib_per_pod,
                    row.recommended_memory_limit_mib_per_pod, row.target_utilization_percent,
                    row.limit_multiplier,
                ))
            for row in self.autoscaling_results:
                conn.execute("INSERT OR REPLACE INTO autoscaling_readiness VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (
                    row.run_id, row.timestamp, row.datacenter, row.cluster, row.application,
                    row.project, row.workload, row.hpa, row.current_replicas,
                    row.desired_replicas, row.min_replicas, row.max_replicas,
                    row.scaling_headroom, row.metric_vs_target, int(row.target_exists),
                    int(row.resource_requests_ready), row.pdb, row.pdb_allowed_disruptions,
                    row.unschedulable_pods, row.nodes, row.zones, row.recent_scaling_events,
                    row.sustained_samples, int(row.sustained_high_utilization), row.severity,
                    row.status, row.recommendation,
                ))
            conn.commit()
        self.logger.write("INFO", "Historical health data saved.", database=str(db_path))

    def email(self, summary):
        notification = self.cfg.get("notifications", {})
        if not notification.get("enabled", False):
            return

        email_severities = set(notification.get("email_severities", ["Critical"]))
        email_findings = [r for r in self.results if r.severity in email_severities]
        if notification.get("send_only_on_problem", True):
            if not email_findings:
                return

        if str(notification.get("method", "outlook")).lower() != "outlook":
            self.logger.write("WARN", "Only Outlook notification is configured in v6.")
            return

        try:
            import win32com.client

            outlook = win32com.client.Dispatch("Outlook.Application")
            mail = outlook.CreateItem(0)

            mail.To = ";".join(notification.get("to_addresses", []))
            mail.CC = ";".join(notification.get("cc_addresses", []))

            state = "CRITICAL" if any(r.severity == "Critical" for r in email_findings) else (
                "WARNING" if email_findings else "HEALTHY"
            )
            mail.Subject = (
                f"[{notification.get('subject_prefix', 'OCP Health')}]"
                f"[{state}] {summary['cluster']} — action required"
            )

            mail.HTMLBody = self.build_exception_email_html(summary)

            attachment_flags = {
                "ocp-health.html": notification.get("attach_html", True),
                "ocp-health.csv": notification.get("attach_csv", True),
                "ocp-health.json": notification.get("attach_json", True),
                "summary.json": notification.get("attach_json", True),
                "ocp-performance.html": notification.get("attach_performance_html", True),
                "ocp-autoscaling-readiness.html": notification.get("attach_autoscaling_html", True),
                "ocp-autoscaling-readiness.csv": notification.get("attach_autoscaling_csv", True),
                "ocp-performance.xlsx": notification.get("attach_excel", True),
            }

            for name, enabled in attachment_flags.items():
                path = self.run_dir / name
                if enabled and path.exists():
                    mail.Attachments.Add(str(path.resolve()))

            if notification.get("display_before_sending", True):
                mail.Display()
                self.logger.write("INFO", "Exception-focused Outlook email opened for review.")
            else:
                mail.Send()
                self.logger.write("INFO", "Exception-focused Outlook email sent.")

        except ImportError:
            self.logger.write(
                "ERROR",
                "pywin32 is not installed. Run: python -m pip install pywin32",
            )
        except Exception as exc:
            self.logger.write("ERROR", "Outlook email failed.", error=str(exc))

    def cleanup(self):
        cutoff=datetime.now()-timedelta(days=int(self.cfg["execution"].get("report_retention_days",30)))
        for p in self.out_root.iterdir():
            if p.is_dir() and p!=self.run_dir:
                try:
                    if datetime.fromtimestamp(p.stat().st_mtime)<cutoff: shutil.rmtree(p)
                except OSError: pass

    def run(self):
        self.logger.write("INFO","OCP health and performance check started.",version=VERSION)
        configured_dcs = {
            str(dc.get("name")): dc
            for dc in self.cfg.get("datacenters", [])
            if dc.get("enabled", True)
        }
        legacy_cluster = self.cfg.get("cluster", {})
        default_scope = {
            "name": str(legacy_cluster.get("datacenter", "CURRENT")),
            "cluster": str(legacy_cluster.get("name", "unknown")),
        }
        if default_scope["name"] in configured_dcs:
            default_scope = configured_dcs[default_scope["name"]]

        work: list[tuple[str, str, dict[str, Any], int | None]] = []
        for app in self.cfg.get("applications",[]):
            if not app.get("enabled",True):
                continue
            targets = app.get("targets")
            if targets:
                for target in targets:
                    dc_name = str(target.get("datacenter", default_scope.get("name", "CURRENT")))
                    scope_cfg = configured_dcs.get(dc_name)
                    if not scope_cfg:
                        scope_cfg = {**default_scope, "name": dc_name}
                    work.append((
                        str(app["name"]), str(target["project"]), dict(scope_cfg),
                        int(target["target_pods"]) if target.get("target_pods") else None,
                    ))
            else:
                for project in app.get("projects",[]):
                    work.append((str(app["name"]), str(project), dict(default_scope), None))

        valid_scopes: dict[tuple[str, str], bool] = {}
        for _, _, scope_cfg, _ in work:
            key = (str(scope_cfg.get("name", "CURRENT")), str(scope_cfg.get("cluster", "unknown")))
            if key in valid_scopes:
                continue
            self.scope.config = scope_cfg
            try:
                self.validate()
                valid_scopes[key] = True
            except Exception as exc:
                valid_scopes[key] = False
                self.logger.write("ERROR", "Datacenter connection validation failed.",
                                  datacenter=key[0], cluster=key[1], error=str(exc))

        workers=max(1, int(self.cfg.get("execution",{}).get("parallel_workers",4)))
        with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="ocp-health") as pool:
            futures={}
            for app, project, scope_cfg, target_pods in work:
                key = (str(scope_cfg.get("name", "CURRENT")), str(scope_cfg.get("cluster", "unknown")))
                if not valid_scopes.get(key):
                    self.scope.config = scope_cfg
                    self.add(app, project, "Project", project, "Critical", "ConnectionFailed",
                             f"Unable to connect to datacenter {key[0]} / cluster {key[1]}.")
                    continue
                future = pool.submit(self.check_project, app, project, scope_cfg, target_pods)
                futures[future] = (app, project, scope_cfg)
            for future in as_completed(futures):
                app,project,scope_cfg=futures[future]
                try: future.result()
                except Exception as exc:
                    self.logger.write("ERROR","Unhandled project check failure.",application=app,project=project,error=str(exc))
                    self.scope.config = scope_cfg
                    self.add(app,project,"Project",project,"Critical","CheckFailed",str(exc))
        summary=self.write_reports(); self.persist_history(summary); self.email(summary); self.cleanup()
        self.logger.write("INFO","OCP health check completed.",**summary)
        print(f"\nReport directory: {self.run_dir}")
        print(f"Critical={summary['critical']} Warning={summary['warning']} Healthy={summary['healthy']} Unknown={summary['unknown']}")
        if summary["critical"]: return 2
        if self.cfg["execution"].get("fail_on_warning",False) and summary["warning"]: return 1
        return 0

def load_config(path: Path):
    try: cfg=json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e: raise RuntimeError(f"Invalid JSON configuration: {e}") from e
    for k in ("cluster","execution","thresholds","applications"):
        if k not in cfg: raise RuntimeError(f"Missing configuration section: {k}")
    return cfg

def main():
    base=Path(__file__).resolve().parent.parent
    p=argparse.ArgumentParser(); p.add_argument("--config",type=Path,default=base/"config"/"ocp-health-config.json")
    p.add_argument("--output",type=Path,default=base/"output"); p.add_argument("--version",action="version",version=VERSION)
    a=p.parse_args()
    try:
        a.output.mkdir(parents=True,exist_ok=True)
        return Checker(load_config(a.config.resolve()),a.config.resolve(),a.output.resolve()).run()
    except KeyboardInterrupt: return 130
    except Exception as e:
        print(f"FATAL: {e}",file=sys.stderr); traceback.print_exc(); return 3

if __name__=="__main__": raise SystemExit(main())
