@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if %ERRORLEVEL%==0 (
  python "%~dp0src\ocp_health_check.py" --config "%~dp0config\ocp-health-config.json" --output "%~dp0output"
  exit /b %ERRORLEVEL%
)
where py >nul 2>nul
if %ERRORLEVEL%==0 (
  py -3 "%~dp0src\ocp_health_check.py" --config "%~dp0config\ocp-health-config.json" --output "%~dp0output"
  exit /b %ERRORLEVEL%
)
echo ERROR: Python 3 not found.
exit /b 3
