# OCP Application Performance, Health & Autoscaling Readiness Automation v6.1

Read-only OpenShift automation for application support teams. It checks live application health, compares pod CPU/memory usage with configured requests and limits, recommends capacity settings, records the datacenter for every finding, and exports operational reports.

## What v6.1 adds

- Autoscaling Readiness for every Deployment, DeploymentConfig and StatefulSet.
- HPA scale-target validation, current/desired/min/max replicas and remaining headroom.
- HPA CPU, memory, object, pod, external and container-resource metrics versus targets.
- CPU and memory request validation required for reliable resource-utilization HPAs.
- PodDisruptionBudget coverage and currently allowed disruptions.
- Unschedulable-pod detection plus replica spread across nodes and zones.
- Recent scale-event counts and repeated scale activity detection.
- Sustained high-utilization detection from scheduled SQLite history samples.
- Dedicated CSV, JSON and HTML reports plus an `Autoscaling Readiness` Excel sheet.

The assessment is read-only. It recommends changes but never scales, patches, restarts or deletes resources.

## What v6 adds

- Live CPU and memory utilization as a percentage of container requests and limits.
- Critical/warning thresholds for CPU, memory, missing requests and missing limits.
- Capacity recommendations per workload and pod.
- Correct datacenter and cluster columns in CSV, JSON and Excel.
- Optional multi-datacenter execution using separate OpenShift contexts or token environment variables.
- A formatted Excel workbook with Run Summary, Pod Performance, Capacity Recommendations and Health Findings sheets.
- Critical-only Outlook email by default; warnings and healthy rows remain in the detailed reports.
- All v5 health checks: pods, controllers, PVCs, services/endpoints, routes, HPA, ReplicaSets, quotas, LimitRanges, node placement, warning events and unhealthy-pod logs.

## Capacity formula

The automation uses:

```text
recommended request per pod = total observed usage / target pods / target utilization
recommended limit per pod   = recommended request per pod * limit multiplier
```

With 3 pods each consuming 0.48 CPU, a target of 4 pods and 80% target utilization:

```text
total usage = 3 * 0.48 = 1.44 cores
request/pod = 1.44 / 4 / 0.80 = 0.45 cores
limit/pod   = 0.45 * 1.5 = 0.675 cores
```

This corrects the undersized `0.288 / 0.432` result shown by the manual calculator screenshot.

## Data source and limitation

Pod usage comes from the OpenShift Metrics API:

```text
/apis/metrics.k8s.io/v1beta1/namespaces/<project>/pods
```

That API is a live snapshot, not a long-range historical peak. Schedule v6 regularly to build execution history. Validate production changes with sustained p95/p99 values from Prometheus/Thanos when available.

## Setup on Windows

1. Install Python 3.10 or newer and the OpenShift `oc.exe` CLI.
2. Copy `oc.exe` to the project root or update `cluster.oc_executable`.
3. Create and activate a virtual environment:

```cmd
py -3.12 -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
```

4. Update `config\ocp-health-config.json` with your applications, projects and Outlook recipients.
5. Confirm access:

```cmd
oc whoami
oc get pods -n your-project
oc get --raw /apis/metrics.k8s.io/v1beta1/namespaces/your-project/pods
```

6. Run:

```cmd
Run-OcpHealthCheck-Interactive.cmd
```

Direct execution:

```cmd
python src\ocp_health_check.py --config config\ocp-health-config.json --output output
```

## Four-datacenter setup

Use `config\ocp-health-config-four-dc-example.json` as the starting point. Replace the sample context, cluster and project values.

Each datacenter can use an existing kubeconfig context:

```json
{
  "name": "GAR",
  "cluster": "production-ocp-gar",
  "context": "gar-production"
}
```

For unattended execution, configure an approved token environment variable instead of saving a token in JSON:

```json
{
  "name": "GAR",
  "cluster": "production-ocp-gar",
  "server": "https://api.gar.example.com:6443",
  "token_environment_variable": "OCP_TOKEN_GAR"
}
```

Map every project explicitly to a datacenter. `target_pods` is optional; when omitted, the current pod count is used:

```json
{
  "name": "EXAMPLE-APP",
  "targets": [
    {"datacenter": "GAR", "project": "example-app-prod", "target_pods": 4},
    {"datacenter": "MAN", "project": "example-app-prod", "target_pods": 4}
  ]
}
```

The program adds `--context`, `--server`, `--token`, or `--kubeconfig` to each read-only `oc` command. It does not globally switch the current OpenShift project or modify a workload.

## Performance thresholds

```json
"performance": {
  "target_utilization_percent": 80,
  "limit_multiplier": 1.5,
  "request_warning_percent": 80,
  "request_critical_percent": 95,
  "limit_warning_percent": 90,
  "missing_requests_severity": "Warning",
  "warn_on_missing_limits": true
}
```

These are starting values. Confirm them with the application/platform team before production scheduling.

## Autoscaling readiness thresholds

```json
"autoscaling": {
  "minimum_production_replicas": 2,
  "headroom_warning_percent": 20,
  "missing_hpa_severity": "Warning",
  "missing_pdb_severity": "Warning",
  "minimum_nodes": 2,
  "minimum_zones": 2,
  "repeated_scaling_event_threshold": 4,
  "sustained_utilization_percent": 85,
  "sustained_min_high_samples": 3,
  "sustained_window_samples": 6
}
```

`sustained_min_high_samples` means the latest consecutive scheduled samples must all meet or exceed the sustained-utilization threshold. Run the automation at a consistent interval so this signal has a meaningful time basis.

## Reports

Every run creates a timestamped folder under `output` with:

- `ocp-health.html`, `ocp-health.csv`, `ocp-health.json`
- `ocp-performance.html`, `ocp-performance.csv`, `ocp-performance.json`
- `ocp-capacity-recommendations.csv`, `ocp-capacity-recommendations.json`
- `ocp-autoscaling-readiness.html`, `ocp-autoscaling-readiness.csv`, `ocp-autoscaling-readiness.json`
- `ocp-performance.xlsx`
- `summary.json`, `execution.jsonl`
- evidence logs for unhealthy pods

Execution summaries are retained in `output\ocp-health-history.db`.

## Outlook behavior

The default configuration sends only Critical findings:

```json
"send_only_on_problem": true,
"email_severities": ["Critical"],
"display_before_sending": true
```

Keep `display_before_sending` enabled during testing. Change it to `false` only after recipients and content are validated.

## Read-only commands

For each configured project, v6 uses commands such as:

```text
oc get project <project> -o json
oc get pods -n <project> -o json
oc get deployments,deploymentconfigs,statefulsets,daemonsets -n <project> -o json
oc get pvc,services,endpoints,routes,hpa,replicasets,resourcequota,limitrange -n <project> -o json
oc get deployments.apps,deploymentconfigs.apps.openshift.io,statefulsets.apps -n <project> -o json
oc get poddisruptionbudgets.policy -n <project> -o json
oc get nodes -o json
oc get events -n <project> --field-selector type=Warning -o json
oc get --raw /apis/metrics.k8s.io/v1beta1/namespaces/<project>/pods
oc logs <unhealthy-pod> -n <project> --all-containers=true --tail=200 --timestamps=true
```

The service account needs read access to those namespace resources, pod logs, and the metrics API. The automation does not scale, restart, delete, patch or edit resources.

## Exit codes

- `0`: completed with no critical findings
- `1`: warnings found when `fail_on_warning` is enabled
- `2`: one or more critical findings
- `3`: fatal configuration or execution failure
- `130`: cancelled by the user
