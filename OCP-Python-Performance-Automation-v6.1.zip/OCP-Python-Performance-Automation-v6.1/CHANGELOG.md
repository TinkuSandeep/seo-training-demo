# Changelog

## 6.1.0

- Added read-only Autoscaling Readiness assessment.
- Added HPA target, condition, replica, metric-target and headroom checks.
- Added CPU/memory request validation for HPA reliability.
- Added PDB coverage and allowed-disruption checks.
- Added unschedulable pod, node spread and zone spread checks.
- Added repeated scaling-event and sustained-utilization detection.
- Added autoscaling CSV, JSON and HTML reports, an Excel sheet and SQLite history.
- Kept Critical-only Outlook notification behavior by default.
- Preserved explicit datacenter and cluster fields across all reports.

No cluster-changing commands are used.
