import json
import sqlite3
import subprocess
import tempfile
import unittest
from pathlib import Path

from openpyxl import load_workbook

from src.ocp_health_check import Checker


class FakeChecker(Checker):
    def oc_run(self, args, check=True):
        if args == ["whoami"]:
            return subprocess.CompletedProcess(args, 0, "test-reader\n", "")
        if "--raw" in args:
            items = []
            for index in range(1, 4):
                items.append({
                    "metadata": {"name": f"app-abc-{index}"},
                    "containers": [{
                        "name": "app",
                        "usage": {"cpu": "480m", "memory": "512Mi"},
                    }],
                })
            return subprocess.CompletedProcess(args, 0, json.dumps({"items": items}), "")
        return subprocess.CompletedProcess(args, 0, "{}", "")

    def oc_json(self, args):
        if args[:2] == ["get", "project"]:
            return {"metadata": {"name": args[2]}}
        if args[:2] == ["get", "pods"]:
            items = []
            for index in range(1, 4):
                items.append({
                    "metadata": {
                        "name": f"app-abc-{index}",
                        "ownerReferences": [{"kind": "ReplicaSet", "name": "app-abc"}],
                        "labels": {"app": "app"},
                    },
                    "status": {
                        "phase": "Running",
                        "conditions": [{"type": "PodScheduled", "status": "True"}],
                    },
                    "spec": {
                        "nodeName": f"node-{1 if index < 3 else 2}",
                        "containers": [{
                            "name": "app",
                            "resources": {
                                "requests": {"cpu": "750m", "memory": "731.428571Mi"},
                                "limits": {"cpu": "1125m", "memory": "1097.142857Mi"},
                            },
                        }],
                    },
                })
            return {"items": items}
        if args[:2] == ["get", "deployments.apps"]:
            return {"items": [{
                "kind": "Deployment",
                "metadata": {"name": "app"},
                "spec": {
                    "replicas": 3,
                    "selector": {"matchLabels": {"app": "app"}},
                    "template": {
                        "metadata": {"labels": {"app": "app"}},
                        "spec": {"containers": [{
                            "name": "app",
                            "resources": {"requests": {"cpu": "750m", "memory": "731Mi"}},
                        }]},
                    },
                },
                "status": {"replicas": 3},
            }]}
        if args[:2] == ["get", "hpa"]:
            return {"items": [{
                "metadata": {"name": "app-hpa"},
                "spec": {
                    "scaleTargetRef": {"kind": "Deployment", "name": "app"},
                    "minReplicas": 2,
                    "maxReplicas": 6,
                    "metrics": [{
                        "type": "Resource",
                        "resource": {
                            "name": "cpu",
                            "target": {"type": "Utilization", "averageUtilization": 75},
                        },
                    }],
                },
                "status": {
                    "currentReplicas": 3,
                    "desiredReplicas": 3,
                    "currentMetrics": [{
                        "type": "Resource",
                        "resource": {"name": "cpu", "current": {"averageUtilization": 64}},
                    }],
                    "conditions": [
                        {"type": "AbleToScale", "status": "True"},
                        {"type": "ScalingActive", "status": "True"},
                    ],
                },
            }]}
        if args[:2] == ["get", "poddisruptionbudgets.policy"]:
            return {"items": [{
                "metadata": {"name": "app-pdb"},
                "spec": {"selector": {"matchLabels": {"app": "app"}}},
                "status": {"disruptionsAllowed": 1},
            }]}
        if args[:2] == ["get", "nodes"]:
            return {"items": [
                {"metadata": {"name": "node-1", "labels": {"topology.kubernetes.io/zone": "zone-a"}}},
                {"metadata": {"name": "node-2", "labels": {"topology.kubernetes.io/zone": "zone-b"}}},
            ]}
        if args[:2] == ["get", "events"]:
            return {"items": [{
                "reason": "SuccessfulRescale",
                "involvedObject": {"name": "app-hpa"},
            }]}
        return {"items": []}


class PerformanceAutomationTest(unittest.TestCase):
    def test_capacity_autoscaling_and_report_outputs(self):
        config = {
            "cluster": {"name": "test-cluster", "datacenter": "GAR", "oc_executable": "oc"},
            "datacenters": [{"name": "GAR", "cluster": "test-cluster", "context": "test"}],
            "execution": {"parallel_workers": 1, "report_retention_days": 30},
            "checks": {
                "pods": False,
                "controllers": False,
                "warning_events": False,
                "persistent_volume_claims": False,
                "services_and_endpoints": False,
                "routes": False,
                "horizontal_pod_autoscalers": False,
                "replica_sets": False,
                "resource_quotas": False,
                "limit_ranges": False,
                "node_placement": False,
                "pod_metrics": True,
                "autoscaling_readiness": True,
            },
            "thresholds": {},
            "performance": {
                "target_utilization_percent": 80,
                "limit_multiplier": 1.5,
                "request_warning_percent": 80,
                "request_critical_percent": 95,
                "limit_warning_percent": 90,
            },
            "autoscaling": {
                "minimum_production_replicas": 2,
                "minimum_nodes": 2,
                "minimum_zones": 2,
                "headroom_warning_percent": 20,
                "repeated_scaling_event_threshold": 4,
                "sustained_utilization_percent": 85,
                "sustained_min_high_samples": 3,
                "sustained_window_samples": 6,
            },
            "notifications": {"enabled": False},
            "history": {"enabled": True, "database_name": "history.db"},
            "applications": [{
                "name": "APP",
                "targets": [{"datacenter": "GAR", "project": "app-prod", "target_pods": 4}],
            }],
        }
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            config_path = root / "config.json"
            config_path.write_text(json.dumps(config), encoding="utf-8")
            checker = FakeChecker(config, config_path, root / "output")
            self.assertEqual(checker.run(), 0)

            capacity = checker.capacity_results()
            self.assertEqual(len(capacity), 1)
            self.assertEqual(capacity[0].current_pods, 3)
            self.assertEqual(capacity[0].target_pods, 4)
            self.assertAlmostEqual(capacity[0].recommended_cpu_request_per_pod, 0.45)
            self.assertAlmostEqual(capacity[0].recommended_cpu_limit_per_pod, 0.675)
            self.assertAlmostEqual(capacity[0].recommended_memory_request_mib_per_pod, 480.0)
            self.assertAlmostEqual(capacity[0].recommended_memory_limit_mib_per_pod, 720.0)
            self.assertEqual({row.datacenter for row in checker.performance_results}, {"GAR"})

            self.assertEqual(len(checker.autoscaling_results), 1)
            readiness = checker.autoscaling_results[0]
            self.assertEqual(readiness.workload, "Deployment/app")
            self.assertEqual(readiness.scaling_headroom, 3)
            self.assertEqual(readiness.metric_vs_target, "cpu=64 / 75")
            self.assertEqual(readiness.pdb, "app-pdb")
            self.assertEqual(readiness.pdb_allowed_disruptions, 1)
            self.assertEqual(readiness.nodes, 2)
            self.assertEqual(readiness.zones, 2)
            self.assertEqual(readiness.severity, "Healthy")

            for filename in [
                "ocp-health.csv",
                "ocp-performance.csv",
                "ocp-capacity-recommendations.csv",
                "ocp-performance.html",
                "ocp-performance.xlsx",
                "ocp-autoscaling-readiness.csv",
                "ocp-autoscaling-readiness.json",
                "ocp-autoscaling-readiness.html",
            ]:
                self.assertTrue((checker.run_dir / filename).exists(), filename)
            workbook = load_workbook(checker.run_dir / "ocp-performance.xlsx", read_only=True)
            self.assertIn("Autoscaling Readiness", workbook.sheetnames)
            with sqlite3.connect(root / "output" / "history.db") as connection:
                self.assertEqual(connection.execute("SELECT COUNT(*) FROM performance_samples").fetchone()[0], 3)
                self.assertEqual(connection.execute("SELECT COUNT(*) FROM capacity_recommendations").fetchone()[0], 1)
                self.assertEqual(connection.execute("SELECT COUNT(*) FROM autoscaling_readiness").fetchone()[0], 1)


if __name__ == "__main__":
    unittest.main()
