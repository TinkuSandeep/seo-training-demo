# OCP Resiliency Diagnostics

Windows package for collecting diagnostics from Garland, Lewisville, Manassas, and Sterling.

## First-time setup

1. Extract this ZIP to a folder such as:
   `C:\Users\<your-id>\tools\oc\OCP-Python-Resiliency-Diagnostics`
2. Double-click `Show-OcpContexts.cmd`.
3. Copy the exact four OCP context names into `config\clusters.json`.
4. Confirm `"project": "pcmp-prod"`.
5. The default app filter is `"webcrawler"`. Change it or set it to `""` to inspect every pod.

## Run

Double-click:

`Run-OcpResiliencyCheck.cmd`

The script collects cluster/server identity, nodes, pods, deployments, ReplicaSets, services,
endpoints, EndpointSlices, routes, events, pod descriptions, current logs, previous logs,
restart counts and current/last container states.

Output is written under:

`logs\ocp_resiliency_diagnostics_YYYYMMDD_HHMMSS.log`

## Requirements

- Windows
- Python 3
- OpenShift `oc` CLI in PATH
- Existing authenticated kubeconfig contexts for the clusters

The script is read-only: it uses get/describe/logs/whoami commands and does not modify OCP resources.
