@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo OCP Resiliency Diagnostics - Four Cluster Health Check
echo ============================================================
echo.

where oc >nul 2>&1
if errorlevel 1 (
  echo ERROR: oc.exe was not found in PATH.
  echo Open a terminal where your OpenShift CLI works, or add oc.exe to PATH.
  pause
  exit /b 1
)

where py >nul 2>&1
if not errorlevel 1 (
  py -3 src\ocp_resiliency_diagnostics.py
) else (
  where python >nul 2>&1
  if errorlevel 1 (
    echo ERROR: Python was not found in PATH.
    pause
    exit /b 1
  )
  python src\ocp_resiliency_diagnostics.py
)

echo.
echo Finished. Check the logs folder for the timestamped diagnostic log.
pause
