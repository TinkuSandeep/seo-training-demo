import subprocess
import datetime
import os
import sys
import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_FILE = BASE_DIR / "config" / "clusters.json"
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(exist_ok=True)

stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
LOG_FILE = LOG_DIR / f"ocp_resiliency_diagnostics_{stamp}.log"

def log(msg=""):
    msg = str(msg)
    print(msg)
    with open(LOG_FILE, "a", encoding="utf-8", errors="replace") as f:
        f.write(msg + "\n")

def run(args, timeout=120):
    log("\n" + "=" * 100)
    log("COMMAND: " + subprocess.list2cmdline(args))
    log("=" * 100)
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout,
                           encoding="utf-8", errors="replace")
        if p.stdout:
            log(p.stdout.rstrip())
        if p.stderr:
            log("STDERR:\n" + p.stderr.rstrip())
        log(f"RETURN CODE: {p.returncode}")
        return p.stdout or ""
    except subprocess.TimeoutExpired:
        log("ERROR: command timed out")
    except Exception as e:
        log(f"ERROR: {e}")
    return ""

def load_config():
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(f"Missing config: {CONFIG_FILE}")
    with open(CONFIG_FILE, encoding="utf-8") as f:
        return json.load(f)

def oc(context, *args):
    return run(["oc", "--context", context, *args])

def diagnose(name, context, project, app_filter):
    log("\n\n" + "#" * 100)
    log(f"CLUSTER: {name.upper()} | CONTEXT: {context} | PROJECT: {project}")
    log("#" * 100)

    oc(context, "whoami", "--show-server")
    oc(context, "get", "nodes", "-o", "wide")
    pods_out = oc(context, "get", "pods", "-n", project, "-o", "wide")
    oc(context, "get", "deploy", "-n", project, "-o", "wide")
    oc(context, "get", "rs", "-n", project, "-o", "wide")
    oc(context, "get", "svc", "-n", project, "-o", "wide")
    oc(context, "get", "endpoints", "-n", project, "-o", "wide")
    oc(context, "get", "endpointslices", "-n", project)
    oc(context, "get", "routes", "-n", project, "-o", "wide")
    oc(context, "get", "events", "-n", project, "--sort-by=.lastTimestamp")

    pod_names = []
    for line in pods_out.splitlines()[1:]:
        cols = line.split()
        if cols and (not app_filter or app_filter.lower() in cols[0].lower()):
            pod_names.append(cols[0])

    log(f"\nMatched pods ({app_filter or 'ALL'}): {', '.join(pod_names) if pod_names else 'NONE'}")

    for pod in pod_names:
        log("\n" + "*" * 100)
        log(f"POD DIAGNOSTICS: {pod}")
        log("*" * 100)
        oc(context, "describe", "pod", pod, "-n", project)
        oc(context, "logs", pod, "-n", project, "--tail=500")
        # Previous logs are especially useful for CrashLoopBackOff.
        oc(context, "logs", pod, "-n", project, "--previous", "--tail=500")
        oc(context, "get", "pod", pod, "-n", project, "-o", "jsonpath={range .status.containerStatuses[*]}Container={.name} Ready={.ready} Restarts={.restartCount} Current={.state} Last={.lastState}{'\\n'}{end}")

def main():
    log("OCP RESILIENCY DIAGNOSTICS")
    log(f"Started: {datetime.datetime.now().isoformat()}")
    try:
        cfg = load_config()
    except Exception as e:
        log(f"CONFIG ERROR: {e}")
        return 2

    if not run(["oc", "version", "--client"]):
        log("WARNING: Could not verify oc client. Make sure oc.exe is in PATH.")

    project = cfg.get("project", "pcmp-prod")
    app_filter = cfg.get("app_filter", "webcrawler")
    clusters = cfg.get("clusters", {})

    for name, context in clusters.items():
        if context and "REPLACE_" not in context:
            diagnose(name, context, project, app_filter)
        else:
            log(f"\nSKIPPING {name}: configure its context in {CONFIG_FILE}")

    log("\n" + "#" * 100)
    log(f"COMPLETED: {datetime.datetime.now().isoformat()}")
    log(f"LOG FILE: {LOG_FILE}")
    log("#" * 100)
    return 0

if __name__ == "__main__":
    sys.exit(main())
