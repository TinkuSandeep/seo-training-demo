@echo off
cd /d "%~dp0"
echo Current OpenShift contexts:
echo ============================================================
oc config get-contexts
echo.
echo Copy the four correct context names into:
echo   config\clusters.json
echo.
pause
